# Copyright Huawei Technologies Co., Ltd. 2024. All rights reserved.
import argparse
import json
import os

import torch
import torch.nn.functional as F
from transformers import AutoTokenizer, AutoModelForCausalLM, AutoConfig

from msmodelslim.pytorch.llm_ptq.anti_outlier import AntiOutlierConfig, AntiOutlier
from msmodelslim.pytorch.llm_ptq.llm_ptq_tools import Calibrator, QuantConfig
from atb_llm.utils import file_utils
from examples.convert.convert_utils import copy_tokenizer_files

# for flex smooth
_BEST_ALPHA = 0.6
_BEST_BETA = 0.3


def parse_args():
    parser = argparse.ArgumentParser(description="Creating quant weights ")
    parser.add_argument("--model_path", type=str, help="The path to model float weights")
    parser.add_argument("--save_path", type=str, help="The path to save quant weights")
    parser.add_argument("--anti_prompt", type=str, default="examples/models/qwen/anti_prompt_pdmix.json", 
                        help="The prompts for anti outlier")
    parser.add_argument("--calib_prompt", type=str, default="examples/models/qwen/calib_prompt_pdmix_72b.json",
                        help="The prompts for anti outlier")
    parser.add_argument("--auto_layer", action='store_true', help="If true, auto select rollback layer")
    parser.add_argument("--trust_remote_code", action='store_true', help="Whether to trust local executable files")
    return parser.parse_args()


def get_anti_dataset(tokenizer, calib_list, device="npu"):
    calib_dataset = []
    max_len = 0
    for calib_data in calib_list:
        inputs = tokenizer(calib_data, return_tensors='pt')
        calib_dataset.append(
            inputs.data['input_ids'].to(device))
        max_len = max(max_len, inputs.data['input_ids'].size(1))
    for i, calib_data in enumerate(calib_dataset):
        calib_dataset[i] = F.pad(calib_data, (0, max_len - calib_data.size(1)), value=0)
    return torch.cat(calib_dataset)


def get_calib_dataset(tokenizer, calib_list, device='npu'):
    calib_dataset = []
    for calib_data in calib_list:
        inputs = tokenizer(calib_data, return_tensors='pt').to(device)
        calib_dataset.append([inputs.data['input_ids']])
    return calib_dataset


def modify_config(model_dir, dest_dir, torch_dtype, quantize_type):
    model_dir = file_utils.standardize_path(model_dir, check_link=False)
    file_utils.check_path_permission(model_dir)
    src_config_filepath = os.path.join(model_dir, 'config.json')
    with file_utils.safe_open(src_config_filepath, 'r', encoding='utf-8') as fr:
        data = json.load(fr)
    data['torch_dtype'] = str(torch_dtype).split(".")[1]
    data['quantize'] = quantize_type
    quantization_config = {
        'kv_quant_type': "C8",
        'pdmix': True
    }
    data['quantization_config'] = quantization_config
    dest_dir = file_utils.standardize_path(dest_dir, check_link=False)
    file_utils.check_path_permission(dest_dir)
    dest_config_filepath = os.path.join(dest_dir, 'config.json')
    with file_utils.safe_open(dest_config_filepath, 'w', encoding='utf-8', is_exist_ok=False) as fw:
        json.dump(data, fw, indent=4)


if __name__ == "__main__":
    args = parse_args()

    config = AutoConfig.from_pretrained(args.model_path, trust_remote_code=args.trust_remote_code)
    tokenizer = AutoTokenizer.from_pretrained(pretrained_model_name_or_path=args.model_path,
                                              trust_remote_code=args.trust_remote_code)
    model = AutoModelForCausalLM.from_pretrained(pretrained_model_name_or_path=args.model_path,
                                                 trust_remote_code=args.trust_remote_code,
                                                 config=config,
                                                 torch_dtype='auto',
                                                 device_map='auto')

    tokenizer.pad_token = tokenizer.eos_token
    model.eval()

    with file_utils.safe_open(args.anti_prompt, 'r', encoding='utf-8') as file:
        anti_prompt = json.load(file)
    with file_utils.safe_open(args.calib_prompt, 'r', encoding='utf-8') as file:
        calib_prompt = json.load(file)

    anti_data = []
    for prompt in anti_prompt:
        tmp = get_anti_dataset(tokenizer, prompt)
        anti_data.append(tmp)
    anti_dataset = []
    for data in anti_data:
        anti_dataset.append([data])
    calib_dataset = []
    for prompt in calib_prompt:
        tmp = get_calib_dataset(tokenizer, prompt, model.device)
        calib_dataset += (tmp)
    anti_config = AntiOutlierConfig(anti_method='m6',
                                    dev_type='npu',
                                    dev_id=model.device.index,
                                    flex_config={'alpha': _BEST_ALPHA, 'beta': _BEST_BETA})
    anti_outlier = AntiOutlier(model,
                               calib_data=anti_dataset,
                               cfg=anti_config)
    anti_outlier.process()

    disable_names = []

    if config.num_hidden_layers == 48:
        disable_names = ['model.layers.2.mlp.down_proj',
                    'model.layers.1.mlp.down_proj',
                    'model.layers.3.mlp.down_proj',
                    'model.layers.4.mlp.down_proj',
                    'model.layers.6.mlp.down_proj',
                    'model.layers.5.mlp.down_proj',
                    'model.layers.0.mlp.down_proj',
                    'model.layers.47.mlp.down_proj',
                    'model.layers.7.mlp.down_proj',
                    'model.layers.46.mlp.down_proj']
    else:
        disable_names = [
            "model.layers.1.self_attn.v_proj",
            "model.layers.1.self_attn.q_proj",
            "model.layers.1.self_attn.k_proj",
            "model.layers.2.self_attn.v_proj",
            "model.layers.2.self_attn.q_proj",
            "model.layers.2.self_attn.k_proj",
            "model.layers.0.mlp.down_proj",
            "model.layers.1.mlp.down_proj",
            "model.layers.3.self_attn.v_proj",
            "model.layers.3.self_attn.q_proj",
            "model.layers.3.self_attn.k_proj",
            "model.layers.5.self_attn.v_proj",
            "model.layers.5.self_attn.q_proj",
            "model.layers.5.self_attn.k_proj",
            "model.layers.2.mlp.down_proj",
            "model.layers.4.self_attn.v_proj",
            "model.layers.4.self_attn.q_proj",
            "model.layers.4.self_attn.k_proj",
            "model.layers.9.self_attn.v_proj",
            "model.layers.9.self_attn.q_proj",
            "model.layers.9.self_attn.k_proj",
            "model.layers.79.mlp.down_proj",
            ]
    if args.auto_layer:
        from msmodelslim.pytorch.llm_ptq.llm_ptq_tools.layer_select import LayerSelector
        ls = LayerSelector(model, range_method='quantile')
        ls.run(anti_dataset)
        disable_names = ls.select_layers_by_disable_level(30)

    quant_config = QuantConfig(
        w_bit=8,
        a_bit=8,
        disable_names=disable_names,
        dev_type='npu',
        dev_id=model.device.index,
        act_method=1,
        pr=1.0,
        w_sym=True,
        mm_tensor=False,
        is_dynamic=False,
        use_kvcache_quant=True)

    calibrator = Calibrator(model, quant_config, calib_data=calib_dataset, disable_level='L0')
    calibrator.run()
    calibrator.save(args.save_path, save_type=["ascendV1"])

    modify_config(args.model_path, args.save_path, config.torch_dtype, quantize_type="w8a8")
    copy_tokenizer_files(args.model_path, args.save_path)