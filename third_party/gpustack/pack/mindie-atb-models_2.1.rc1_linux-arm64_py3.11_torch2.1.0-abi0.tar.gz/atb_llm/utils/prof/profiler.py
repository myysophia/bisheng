# Copyright Huawei Technologies Co., Ltd. 2025-2025. All rights reserved


try:
    import functools
    from ..log.logging import logger
    from atb_llm.utils.env import ENV
    from ms_service_profiler import Profiler, Level
    from ms_service_profiler.mstx import service_profiler

    if ENV.framework_backend.lower() == 'ms':
        import mindspore
        npu = mindspore.hal
    else:
        import torch
        import importlib
        importlib.import_module('torch_npu')
        npu = torch.npu

    def no_error(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except Exception as err:
                logger.debug(f"[prof error] {err}")
                return None
        return wrapper

    @no_error
    def span_start(name, sync=False, domain="ModelExecute", *args, **kwargs):
        if sync and service_profiler.is_enable(Level.INFO):
            npu.synchronize()
        return Profiler(Level.INFO).domain(domain).span_start(name)

    @no_error
    def span_end(prof, sync=False, *args, **kwargs):
        if sync and service_profiler.is_enable(Level.INFO):
            npu.synchronize()
        return prof.span_end()

    @no_error
    def span_req(prof, req_list):
        return prof.res([{"rid": str(rid)} for rid in req_list])

except ImportError:
    from enum import Enum

    class Level(int, Enum):
        INFO = 20

    class Profiler:
        def __init__(self, *args, **kwargs):
            pass

        def __getattribute__(self, name):
            if name != "empty_func":
                return self.empty_func
            else:
                return super().__getattribute__(name)
            
        def empty_func(self, *args, **kwargs):
            return self

    def span_start(*args, **kwargs):
        return 0

    def span_end(*args, **kwargs):
        pass

    def span_req(prof, req_list):
        pass
