# Copyright Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.
from dataclasses import dataclass

from ..base.router import BaseRouter


@dataclass
class JanusRouter(BaseRouter):
    
    def check_config_janus(self, config):
        super().check_config(config)
    
    def get_config(self):
        config_cls = self.get_config_cls()
        config = config_cls.from_dict(self.config_dict)
        config.model_name_or_path = self.model_name_or_path
        self.check_config(config)
        return config