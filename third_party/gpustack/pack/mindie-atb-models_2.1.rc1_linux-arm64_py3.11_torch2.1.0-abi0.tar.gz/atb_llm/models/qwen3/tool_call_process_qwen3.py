#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright (c) Huawei Technologies Co., Ltd. 2024-2025. All rights reserved.
import re
from typing import Pattern

from ..base.tool_call_parser import ToolsCallProcessorWithXml


class ToolsCallProcessorQwen3(ToolsCallProcessorWithXml):
    def __init__(self, tokenizer):
        super().__init__(tokenizer)
        self._tool_call_regex = re.compile(r'<tool_call>\s*({.*?})\s*</tool_call>', re.DOTALL)

    @property
    def tool_call_start_token(self) -> str:
        return "<tool_call>"                    # start_token of qwen3

    @property
    def tool_call_end_token(self) -> str:
        return "</tool_call>"                   # end_token of qwen3

    @property
    def tool_call_start_token_id(self) -> int:
        return 151657                           # start_token_id of qwen3

    @property
    def tool_call_end_token_id(self) -> int:
        return 151658                           # end_token_id of qwen3

    @property
    def tool_call_regex(self) -> Pattern:
        return self._tool_call_regex
