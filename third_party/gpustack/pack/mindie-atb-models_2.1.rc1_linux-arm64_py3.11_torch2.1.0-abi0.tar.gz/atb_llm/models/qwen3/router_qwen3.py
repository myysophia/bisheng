# Copyright Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.
from dataclasses import dataclass

from .config_qwen3 import Qwen3Config
from .input_builder_qwen3 import Qwen3InputBuilder
from .tool_call_process_qwen3 import ToolsCallProcessorQwen3
from ..base.reasoning_parser import CommonReasoningParser
from ..qwen2.router_qwen2 import Qwen2Router


@dataclass
class Qwen3Router(Qwen2Router):

    def __post_init__(self):
        # qwen3 继承qwen2
        super().__post_init__()
        self.model_type = "qwen2"
        self.model_type_cap = self.model_type.capitalize()

    def get_config(self):
        self.config_dict.update({"transformers_version": self.transformers_version})
        config = Qwen3Config.from_dict(self.config_dict)
        super().check_config(config)
        return config

    def get_reasoning_parser(self):
        """initialize reasoning parser"""
        return CommonReasoningParser(self.config)

    def get_toolscallprocessor(self):
        return ToolsCallProcessorQwen3(self.tokenizer)

    def get_input_builder(self):
        return Qwen3InputBuilder(self.tokenizer)
