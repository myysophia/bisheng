# Copyright Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

from ..base.input_builder import InputBuilder


class Qwen3InputBuilder(InputBuilder):
    """
    1、Supporting the funcation call
    2、Support for request-level closure of the think
    """

    def __init__(self, tokenizer, **kwargs):
        super().__init__(tokenizer, **kwargs)
        # Thinking chain switch for weight configuration
        self.config_enable_thinking = tokenizer.init_kwargs.get("enable_thinking", True)

    def _apply_chat_template(self, conversation, tools_msg=None, **kwargs):
        if not hasattr(self.tokenizer, "apply_chat_template"):
            raise RuntimeError("Your transformers version is detected to be <4.34. This message indicates that this "
                               "model is not supported to run on transformers <4.34. You can upgrade transformers to "
                               "4.34 or above, or rewrite the InputBuilder provided with this model and load it in the "
                               "router.")
        if not self.tokenizer.chat_template:
            raise RuntimeError("The model does not appear to be a chat model because it is not configured with a "
                               "`chat_template`.")
        # Request-level switch > Weight tokenizer_config
        request_enable_thinking = kwargs.get("chat_template_kwargs", {}).get("enable_thinking", None)
        if request_enable_thinking is not None:
            enable_thinking = request_enable_thinking
        else:
            enable_thinking = self.config_enable_thinking
        kwargs["enable_thinking"] = enable_thinking
        if tools_msg:
            return self.tokenizer.apply_chat_template(conversation, tools=tools_msg.get("tools", None), **kwargs)
        return self.tokenizer.apply_chat_template(conversation, **kwargs)
