# Copyright Huawei Technologies Co., Ltd. 2025. All rights reserved.

from dataclasses import dataclass

from ..qwen2.config_qwen2 import Qwen2Config


@dataclass
class Qwen3Config(Qwen2Config):
    use_qk_norm: bool = True
    is_reasoning_model: bool = True
    start_reasoning_token_id = 151667
    end_reasoning_token_id = 151668
    attention_bias: bool = False

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.reasoning_config.start_reasoning_token_id = self.start_reasoning_token_id
        self.reasoning_config.end_reasoning_token_id = self.end_reasoning_token_id
