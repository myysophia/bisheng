# coding=utf-8
# Copyright 2022 EleutherAI and the HuggingFace Inc. team. All rights reserved.
#
# This code is based on EleutherAI's GPT-NeoX library and the GPT-NeoX
# and OPT implementations in this library. It has been modified from its
# original forms to accommodate minor architectural differences compared
# to GPT-NeoX and OPT used by the Meta AI team that trained the model.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from ... import nn
from ...layers.attention.attention import Attention
from ...layers.mlp.mlp import Mlp
from ...utils.loader.weight_loader import WeightLoader
from ...models.base.base_lm import ConfigMetadata, InferenceParameter
from ...utils.loader.linear_loader import MergedColumnParallelLinear, RowParallelLinear
from ...utils.loader.embedding_loader import ParallelEmbedding, ReplicatedEmbedding
from ...utils.loader.normalization_loader import RmsNorm
from ...models.base.modeling_python import BaseLayer, BaseModel
from ...models.base.config import BaseConfig


LLAMA_EMBEDDING_PARALLEL_THRESHOLD = 128256  # vocab size of llama3


class LlamaAttention(Attention):
    def __init__(
            self, config: BaseConfig, weight_loader: WeightLoader, prefix: str,
            config_metadata: ConfigMetadata, infer_param: InferenceParameter, **kwargs):
        super().__init__(config, weight_loader, prefix, config_metadata, infer_param, **kwargs)

        self.qkv = MergedColumnParallelLinear.load(
            config, weight_loader,
            [f'{self.prefix}.q_proj', f'{self.prefix}.k_proj', f'{self.prefix}.v_proj'])

        self.dense = RowParallelLinear.load(
            config, weight_loader, [f'{self.prefix}.o_proj']
        )


class LlamaMlp(Mlp):
    def __init__(
            self, config: BaseConfig, weight_loader: WeightLoader, prefix: str,
            config_metadata: ConfigMetadata, infer_param: InferenceParameter, **kwargs):
        super().__init__(config, weight_loader, prefix, config_metadata, infer_param, **kwargs)

        self.gate_up = MergedColumnParallelLinear.load(
            config, weight_loader,
            [f'{self.prefix}.gate_proj', f'{self.prefix}.up_proj'])

        self.down = RowParallelLinear.load(
            config, weight_loader, [f'{self.prefix}.down_proj']
        )


class LlamaLayer(BaseLayer):
    def __init__(self, config: BaseConfig, weight_loader: WeightLoader, prefix: str, layer_idx: int, **kwargs):        
        super().__init__(config, weight_loader, prefix, layer_idx, **kwargs)
        self.self_attn = LlamaAttention(self.config, weight_loader, f"{self.prefix}.self_attn", **kwargs)
        self.mlp = LlamaMlp(self.config, weight_loader, f"{self.prefix}.mlp", **kwargs)
        self.input_layernorm = RmsNorm.load(config, weight_loader, f"{self.prefix}.input_layernorm")
        self.post_attention_layernorm = RmsNorm.load(config, weight_loader, f"{self.prefix}.post_attention_layernorm")


class LlamaModel(BaseModel):
    def __init__(self, config: BaseConfig, weight_loader: WeightLoader, prefix: str = "model", **kwargs):
        super().__init__(config, weight_loader, prefix, **kwargs)
        self.parallel_embedding = config.vocab_size >= LLAMA_EMBEDDING_PARALLEL_THRESHOLD

        self.embed_tokens = (ParallelEmbedding if self.parallel_embedding else ReplicatedEmbedding).load(
            config, weight_loader, f"{self.prefix}.embed_tokens"
        )
        self.layers = nn.ModuleList([LlamaLayer(self.config, weight_loader, self.prefix, layer_idx, **kwargs)
                            for layer_idx in range(self.config.num_hidden_layers)])
        self.norm = RmsNorm.load(config, weight_loader, f"{self.prefix}.norm")