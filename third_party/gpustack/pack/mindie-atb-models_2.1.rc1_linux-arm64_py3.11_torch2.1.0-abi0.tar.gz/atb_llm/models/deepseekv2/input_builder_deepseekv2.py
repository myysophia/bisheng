# Copyright (c) Huawei Technologies Co., Ltd. 2024-2025. All rights reserved.
from ..base.input_builder import InputBuilder


class Deepseekv2InputBuilder(InputBuilder):
    def _apply_chat_template(self, conversation, tools_msg=None, **kwargs):
        if not hasattr(self.tokenizer, "apply_chat_template"):
            raise RuntimeError("Your transformers version is detected to be <4.34. This message indicates that this "
                               "model is not supported to run on transformers <4.34. You can upgrade transformers to "
                               "4.34 or above, or rewrite the InputBuilder provided with this model and load it in the "
                               "router.")
        if not self.tokenizer.chat_template:
            raise RuntimeError("The model does not appear to be a chat model because it is not configured with a "
                               "`chat_template`.")
        if tools_msg:
            return self.tokenizer.apply_chat_template(conversation, tools=tools_msg.get("tools", None), **kwargs)
        return self.tokenizer.apply_chat_template(conversation, **kwargs)