# Copyright (c) Huawei Technologies Co., Ltd. 2024-2025. All rights reserved.
import re
from typing import Pattern
from ..base.tool_call_parser import ToolsCallProcessorWithXml


class ToolsCallProcessorDeepseekv2(ToolsCallProcessorWithXml):
    @property
    def tool_calls_start_token(self) -> str:
        return "<｜tool▁calls▁begin｜>"

    @property
    def tool_calls_end_token(self) -> str:
        return "<｜tool▁calls▁end｜>"

    @property
    def tool_calls_start_token_id(self) -> int:
        return 128806

    @property
    def tool_calls_end_token_id(self) -> int:
        return 128807

    @property
    def tool_call_start_token(self) -> str:
        return "<｜tool▁call▁begin｜>"

    @property
    def tool_call_end_token(self) -> str:
        return "<｜tool▁call▁end｜>"

    @property
    def tool_call_start_token_id(self) -> int:
        return 128808

    @property
    def tool_call_end_token_id(self) -> int:
        return 128809

    @property
    def tool_call_regex(self) -> Pattern:
        return re.compile(
            r"<｜tool▁call▁begin｜>(?P<type>.*)<｜tool▁sep｜>(?P<function_name>.*)\n"
            r"```json\n(?P<function_arguments>.*)\n```<｜tool▁call▁end｜>"
        )

    @property
    def stream_tool_call_portion_regex(self) -> Pattern:
        return re.compile(
            r"(?P<type>.*)<｜tool▁sep｜>(?P<function_name>.*)\n```json\n(?P<function_arguments>.*[^\n`])"
        )

    @property
    def stream_tool_call_name_regex(self) -> Pattern:
        return re.compile(
            r"(?P<type>.*)<｜tool▁sep｜>(?P<function_name>.*)\n")

    @staticmethod
    def get_tool_call_json(matches):
        tool_calls = []
        try:
            for match in matches:
                _, name, arguments = match
                tool_calls.append({"name": name, "arguments": arguments})
        except Exception:
            tool_calls = []
        return tool_calls