# Copyright Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.
from dataclasses import dataclass

from ..base.router import BaseRouter
from ..base.model_utils import safe_get_tokenizer_from_pretrained
from .flash_causal_deepseekv2 import DeepseekV2Config
from ..base.reasoning_parser import CommonReasoningParser
from .input_builder_deepseekv2 import Deepseekv2InputBuilder
from .tool_call_process_deepseekv2 import ToolsCallProcessorDeepseekv2

from ...utils.log import logger
from ...utils.log.error_code import ErrorCode

from ...utils.parameter_validators import (
    IntParameterValidator, FloatParameterValidator, BooleanParameterValidator, RangeParamaterValidator, 
    DictionaryParameterValidator, Field
)


@dataclass
class Deepseekv2Router(BaseRouter):
    @classmethod
    def get_llm_config_validators(cls):
        '''
        override this method to add validators for deepseekv2 config
        '''
        llm_config_validators = super().get_llm_config_validators()
        deepseekv2_config_validators = DictionaryParameterValidator({
            "eplb": DictionaryParameterValidator({
                "level": RangeParamaterValidator(range_list=[0, 1, 2, 3]),
                "num_redundant_experts": IntParameterValidator(Field(ge=0, le=256)),
                "aggregate_threshold": IntParameterValidator(Field(ge=100)),  # 最小门限值100，作为统计周期
                "buffer_expert_layer_num": IntParameterValidator(Field(ge=1)),  # 大于等于1，小于moe层数
                "num_expert_update_ready_countdown": IntParameterValidator(Field(gt=1)),  # 检测周期，大于1，小于门限值一半
            }),
            "ep_level": RangeParamaterValidator(range_list=[1, 2]),
            "communication_backend": DictionaryParameterValidator({
                "decode": RangeParamaterValidator(range_list=["lccl", "hccl"]),
                "prefill": RangeParamaterValidator(range_list=["lccl", "hccl"]),
            }),
            "enable_oproj_prefetch": BooleanParameterValidator(),
            "enable_mlapo_prefetch": BooleanParameterValidator(),
            "num_dangling_shared_experts": IntParameterValidator(Field(gt=-1), special_values=[-1]),
            "enable_swiglu_quant_for_shared_experts": BooleanParameterValidator(),
            "enable_init_routing_cutoff": BooleanParameterValidator(),
            "topk_scaling_factor": FloatParameterValidator(Field(ge=0.0, le=1.0)),
            "mlp_full_tp": BooleanParameterValidator(),
            "h3p": DictionaryParameterValidator({
                "enable_qkvdown_dp": BooleanParameterValidator(),
                "enable_gating_dp": BooleanParameterValidator(),
                "enable_shared_expert_dp": BooleanParameterValidator(),
                "enable_shared_expert_overlap": BooleanParameterValidator(),
            })
        })

        llm_config_validators["models"]["deepseekv2"] = deepseekv2_config_validators
        return llm_config_validators

    def get_config(self):
        config = DeepseekV2Config.from_dict(self.config_dict)
        self.check_config_deepseekv2(config)
        if config.quantization_config.fa_quant_type is not None:
            self.llm_config.llm.kv_cache_options.enable_nz = True
                
        return config

    def get_tokenizer(self):
        tokenizer = safe_get_tokenizer_from_pretrained(
            self.tokenizer_path,
            padding_side="left",
            trust_remote_code=False,
        )
        tokenizer.pad_token_id = tokenizer.eos_token_id
        return tokenizer

    def get_reasoning_parser(self):
        """initialize reasoning parser"""
        return CommonReasoningParser(self.config)

    def get_toolscallprocessor(self):
        return ToolsCallProcessorDeepseekv2(self.tokenizer)

    def get_input_builder(self):
        return Deepseekv2InputBuilder(self.tokenizer)

    def check_config_deepseekv2(self, config):
        super().check_config(config)
        attribute_ranges = {
            "num_experts_per_tok": (1, 256),
            "n_shared_experts": (0, 256),
            "first_k_dense_replace": (0, 61),
            "n_routed_experts ": (2, 256),
            "q_lora_rank": (1, 1536),
            "qk_nope_head_dim": (1, 128),
            "qk_rope_head_dim": (1, 64),
        }
        for attr, (min_val, max_val) in attribute_ranges.items():
            if not hasattr(config, attr) or getattr(config, attr) is None:
                continue
            value = getattr(config, attr)
            if value < min_val or value > max_val:
                msg = f"config.{attr} = {value}, must be between {min_val} and {max_val}"
                logger.error(msg, ErrorCode.ATB_MODELS_PARAM_OUT_OF_RANGE)
                raise ValueError(msg)

        if getattr(config, "num_experts_per_tok") > getattr(config, "n_routed_experts"):
            msg = f"config.num_experts_per_tok should be less than config.n_routed_experts, " \
                  f"but {config.num_experts_per_tok=}, {config.n_routed_experts=}"
            logger.error(msg, ErrorCode.ATB_MODELS_PARAM_OUT_OF_RANGE)
            raise ValueError(msg)

        if getattr(config, "first_k_dense_replace") > getattr(config, "num_hidden_layers"):
            msg = f"config.first_k_dense_replace should be less than config.num_hidden_layers, " \
                  f"but {config.first_k_dense_replace=}, {config.num_hidden_layers=}"
            logger.error(msg, ErrorCode.ATB_MODELS_PARAM_OUT_OF_RANGE)
            raise ValueError(msg)

        if config.topk_method not in ["greedy", "group_limited_greedy", "noaux_tc"]:
            msg = "`topk_method`'s type field must be one of ['greedy', 'group_limited_greedy', 'noaux_tc'], " \
                  f"got {config.topk_method}"
            logger.error(msg, ErrorCode.ATB_MODELS_PARAM_OUT_OF_RANGE)
            raise ValueError(msg)

        # 校验topk参数是否匹配
        if config.topk_method == "greedy" and config.topk_group != config.n_group and config.n_group != 1:
            msg = f"`topk_method is `greedy`, please set `topk_group=1` and `n_group=1`, " \
                  f"got topk_group={config.topk_group}, n_group={config.n_group}"
            logger.error(msg, ErrorCode.ATB_MODELS_PARAM_OUT_OF_RANGE)
            raise ValueError(msg)