# Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
import threading
from ..eplb_planner.eplb_forwarder import EplbForwarder
from ..eplb_planner.eplb_planner import EplbPlanner, DynamicConfig
from ..eplb_planner.eplb_thread_handler import do_eplb
from ..eplb_loader.eplb_loader import EplbRebalanceLoader


class EplbWorker:
    def __init__(self, model_runner, rank, model_id, device):
        self.model = model_runner
        self.model.model.warmup_is_end = False
        self.enable_eplb_multi_process = True
        self.eplb_loader = EplbRebalanceLoader(model_runner.model, int(rank), model_id, self.enable_eplb_multi_process)
        self.eplb_forwarder = EplbForwarder(model_runner.model, self.eplb_loader)
        self.eplb_planner = EplbPlanner(DynamicConfig(), policy_type=1, enable_eplb_multi_process=True)
        # 起do eplb线程,收集信息与执行权重更新操作
        t_eplb_load = threading.Thread(
            target=do_eplb,
            args=(
                (self, self.eplb_loader, self.eplb_planner),
                int(rank),
                device,
                self.model.model.init_expert_table
            )
        )
        t_eplb_load.daemon = True
        t_eplb_load.start()
