# Copyright Huawei Technologies Co., Ltd. 2025-2026. All rights reserved.
import numpy as np
import torch_npu
from atb_llm.utils.env import ENV
from atb_llm.utils.log import logger


def do_eplb(args, rank_id: int, device: int, old_map=None):
    pa_runner, eplb_loader, eplb_planner = args
    logger.info(f"[rank{rank_id}] device_id[{device}] planner thread start!")
    torch_npu.npu.set_device(device)
    copy_stream = torch_npu.npu.Stream(device)

    flash_deepseekv2_model = pa_runner.model.model

    exit_flag = False
    try:
        while True:
            # 1. 通过阻塞队列阻塞，等待forward唤醒
            pa_runner.eplb_forwarder.planner_block_queue.get()
            load_info = pa_runner.eplb_forwarder.fetch_and_sum_load_info()
            if load_info is None:
                continue

            # 2. 调取planner, 获取专家表
            changed = 0
            if flash_deepseekv2_model.warmup_is_end:
                changed, priority, new_map = eplb_planner.calculate_rebalance_experts(load_info, old_map)
                pa_runner.eplb_forwarder.new_map = new_map
                logger.debug(f"EPLB changed {changed}")

            # 如果专家分布表没有更新，不继续执行专家权重更新操作
            if flash_deepseekv2_model.warmup_is_end and changed == 0:
                continue
            if not flash_deepseekv2_model.warmup_is_end:
                new_map = old_map
            transpose_new_map = np.transpose(new_map, (1, 0, 2)).tolist()

            # 3. 下传update操作
            update_times = eplb_loader.h2d_update_times(flash_deepseekv2_model)
            for i in range(update_times):
                logger.debug(f"[rank{ENV.rank}] start round{i} H2D update")
                if not flash_deepseekv2_model.warmup_is_end:
                    pa_runner.eplb_forwarder.set_update_flag(True)
                    break
                need_update = True
                try:
                    need_update = eplb_loader.do_load_prepare_h2d(copy_stream, transpose_new_map[rank_id], i)
                except Exception as e:
                    if not flash_deepseekv2_model.warmup_is_end:
                        exit_flag = True
                    raise Exception from e

                if not need_update:
                    continue

                pa_runner.eplb_forwarder.set_update_flag(True)
                logger.debug(f"[rank{ENV.rank}] finish round{i} H2D update")
                # 阻塞等待D2D完成
                pa_runner.eplb_forwarder.block_update_queue.get()

            # 4. 更新old_map
            if flash_deepseekv2_model.warmup_is_end:
                old_map = new_map
    except Exception as e:
        logger.warning(f"[rank{ENV.rank}] eplb planner thread raise exception: {e}")
        import traceback
        traceback.print_exc()
        if exit_flag:
            raise Exception from e
