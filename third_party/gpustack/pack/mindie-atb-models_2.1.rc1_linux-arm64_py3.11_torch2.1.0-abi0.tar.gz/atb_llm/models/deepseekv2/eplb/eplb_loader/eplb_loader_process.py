# Copyright Huawei Technologies Co., Ltd. 2025-2026. All rights reserved.
from torch import multiprocessing as mp
import torch
from atb_llm.utils.log import logger

from atb_llm.utils.weights import Weights
from atb_llm.utils.layers import (
    TensorParallelRowLinear,
    TensorParallelColumnLinear
)


class WeightsParam:
    def __init__(
            self,
            device,
            dtype,
            process_group,
            quantize=None,
            is_gqa=False,
            mapping=None,
            extension=".safetensors",
            **kwargs
    ):
        self.device = device
        self.dtype = dtype
        self.process_group = process_group
        self.quantize = quantize
        self.is_gqa = is_gqa
        self.mapping = mapping
        self.extension = extension


class EplbLoaderProcess():
    def __init__(self, model_name_or_path, weights):
        self.is_alive = True
        weights_param = WeightsParam(device=weights.device,
                                     dtype=weights.dtype,
                                     process_group=weights.process_group,
                                     quantize=weights.quantize,
                                     is_gqa=weights.is_gqa,
                                     mapping=weights.mapping,
                                     )
        spawn_ctx = mp.get_context("spawn")
        self.weight_column_linear_in = spawn_ctx.Queue()
        self.weight_column_linear_out = spawn_ctx.Queue()
        self.weight_column_linear_process \
            = spawn_ctx.Process(target=EplbLoaderProcess._do_load_weight_column_linear_from_ssd,
                                args=(model_name_or_path, weights_param,
                                      self.weight_column_linear_in, self.weight_column_linear_out))
        self.weight_column_linear_process.start()

        self.weight_row_linear_in = spawn_ctx.Queue()
        self.weight_row_linear_out = spawn_ctx.Queue()
        self.weight_row_linear_process = (
            spawn_ctx.Process(target=EplbLoaderProcess._do_load_weight_row_linear_from_ssd,
                              args=(model_name_or_path, weights_param,
                                    self.weight_row_linear_in, self.weight_row_linear_out))
        )
        self.weight_row_linear_process.start()

    @staticmethod
    def _do_load_weight_column_linear_from_ssd(model_name_or_path, weights_param, in_q, out_q):
        try:
            weights = Weights(
                model_name_or_path, weights_param.device, weights_param.dtype,
                process_group=weights_param.process_group,
                quantize=weights_param.quantize,
                is_gqa=weights_param.is_gqa,
                extension=".safetensors",
                mapping=weights_param.mapping
            )
        except Exception as e:
            import traceback
            traceback.print_exc()
            raise Exception from e

        while True:
            logger.debug("do_load_weight_column_linear_from_ssd process start.")
            args = in_q.get()
            if args == "exist":
                break

            config, pack_prefixes, bias = args
            result, tensor_weight, tensor_weight_scale, tensor_weight_offset \
                = EplbLoaderProcess._do_load_weight_column_linear_from_ssd_(weights, config, pack_prefixes, bias)
            logger.debug(f"do_load_weight_column_linear_from_ssd process finished: {result}.")
            out_q.put((result, tensor_weight, tensor_weight_scale, tensor_weight_offset))

    @staticmethod
    def _do_load_weight_column_linear_from_ssd_(weights, config, pack_prefixes, bias):
        result = TensorParallelColumnLinear.load_moe(
            config,
            prefix_list=pack_prefixes,
            weights=weights,
            bias=bias
        )

        tensor_weight = result.linear.weight
        tensor_weight.share_memory_()
        tensor_weight_scale = result.linear.weight_scale
        tensor_weight_scale.share_memory_()
        tensor_weight_offset = result.linear.weight_offset
        tensor_weight_offset.share_memory_()

        # 清除linear buffer，避免复杂tensor序列化
        try:
            result.linear.register_buffer('weight', torch.tensor([0]))
            result.linear.register_buffer('weight_scale', torch.tensor([0]))
            result.linear.register_buffer('weight_offset', torch.tensor([0]))
        except KeyError:
            pass
        return result, tensor_weight, tensor_weight_scale, tensor_weight_offset

    @staticmethod
    def _do_load_weight_row_linear_from_ssd(model_name_or_path, weights_param, in_q, out_q):
        try:
            weights = Weights(
                model_name_or_path, weights_param.device, weights_param.dtype,
                process_group=weights_param.process_group,
                quantize=weights_param.quantize,
                is_gqa=weights_param.is_gqa,
                extension=".safetensors",
                mapping=weights_param.mapping
            )
        except Exception as e:
            import traceback
            traceback.print_exc()
            raise Exception from e

        while True:
            logger.debug("do_load_weight_row_linear_from_ssd_ process start.")
            args = in_q.get()
            if args == "exist":
                break
            config, prefix_list, process_group, bias = args
            result, tensor_weight, tensor_weight_scale, tensor_weight_offset = (
                EplbLoaderProcess._do_load_weight_row_linear_from_ssd_(
                    weights, config, prefix_list, process_group, bias
                )
            )
            logger.debug(f"do_load_weight_row_linear_from_ssd_ process finished: result {result}.")
            out_q.put((result, tensor_weight, tensor_weight_scale, tensor_weight_offset))

    @staticmethod
    def _do_load_weight_row_linear_from_ssd_(weights, config, prefix_list, process_group, bias):
        result = TensorParallelRowLinear.load_moe(
            config,
            prefix_list=prefix_list,
            process_group=process_group,
            weights=weights,
            bias=bias
        )
        # 将张量的存储放入共享内存
        tensor_weight = result.linear.weight
        tensor_weight.share_memory_()  # 标记为共享内存
        tensor_weight_scale = result.linear.weight_scale
        tensor_weight_scale.share_memory_()  # 标记为共享内存
        tensor_weight_offset = result.linear.weight_offset
        tensor_weight_offset.share_memory_()  # 标记为共享内存
        # 清除linear buffer，避免复杂tensor序列化
        try:
            result.linear.register_buffer('weight', torch.tensor([0]))
            result.linear.register_buffer('weight_scale', torch.tensor([0]))
            result.linear.register_buffer('weight_offset', torch.tensor([0]))
        except KeyError:
            pass
        return result, tensor_weight, tensor_weight_scale, tensor_weight_offset

    def graceful_exit(self, signum, frame):
        self.is_alive = False
        self.weight_column_linear_in.put("exist")
        self.weight_row_linear_in.put("exist")
        self.weight_column_linear_process.terminate()
        self.weight_row_linear_process.terminate()

    def shutdown(self):
        self.graceful_exit(0, 0)

    def load_weight_column_linear_from_ssd(self, config, pack_prefixes, bias):
        self.weight_column_linear_in.put((config, pack_prefixes, bias))
        result = None
        if self.is_alive and self.weight_column_linear_process.is_alive():
            try:
                result, tensor_weight, tensor_weight_scale, tensor_weight_offset = self.weight_column_linear_out.get()
                # 组装回result
                result.linear.register_buffer('weight', tensor_weight)
                result.linear.register_buffer('weight_scale', tensor_weight_scale)
                result.linear.register_buffer('weight_offset', tensor_weight_offset)
            except KeyError:
                pass
            except Exception as e:
                if self.is_alive:
                    raise e
                else:
                    result = None
        return result

    def load_weight_row_linear_from_ssd(self, config, prefix_list, process_group, bias):

        self.weight_row_linear_in.put((config, prefix_list, process_group, bias))
        if self.is_alive and self.weight_row_linear_process.is_alive():
            try:
                result, tensor_weight, tensor_weight_scale, tensor_weight_offset = self.weight_row_linear_out.get()
                # 组装回result
                result.linear.register_buffer('weight', tensor_weight)
                result.linear.register_buffer('weight_scale', tensor_weight_scale)
                result.linear.register_buffer('weight_offset', tensor_weight_offset)
            except KeyError:
                pass
            except Exception as e:
                if self.is_alive:
                    raise e
                else:
                    result = None
        else:
            result = None
        return result
