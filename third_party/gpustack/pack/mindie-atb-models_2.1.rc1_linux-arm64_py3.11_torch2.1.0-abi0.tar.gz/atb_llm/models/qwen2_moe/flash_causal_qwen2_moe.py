# Copyright Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
import json
import math
from typing import Optional, List, Tuple

import torch

from atb_llm.utils.log import logger
from atb_llm.utils.env import ENV
from atb_llm.utils.data.moe_weight_wrapper import MoeMlpWrapper, MoeWeightWrapper
from atb_llm.models.qwen2_moe.modeling_qwen2_moe import FlashQwenModel
from atb_llm.models.qwen2_moe.configuration_qwen2_moe import Qwen2MoeConfig
from atb_llm.models.deepseekv2.flash_causal_deepseekv2 import ExpertParallelDegree
from atb_llm.models.base.flash_causal_lm import FlashForCausalLM
from atb_llm.utils.data.weight_wrapper import AttnWrapper
from atb_llm.utils.layers import load_column_multi
from atb_llm.utils.layers.norm.fast_layer_norm import NormType
from atb_llm.utils.moe_utils import assign
from atb_llm.utils.weights import ProcessGroupType


class FlashQwen2moeForCausalLM(FlashForCausalLM):
    def __init__(self, config, weights, **kwargs):
        self.distributed_enable = kwargs.get('distributed_enable', False)

        self.max_batch_size = kwargs.get('max_batch_size', 0)
        if not self.distributed_enable:
            self.max_batch_size = 0

        super().__init__(config, weights, **kwargs)

        self.ep = self.mapping.has_moe_ep()
        if self.ep:
            self.ep_level = ExpertParallelDegree.DYNAMIC_EP
        else:
            self.ep_level = ExpertParallelDegree.NO_EP
        config.ep_level = self.ep_level

        self.model = FlashQwenModel(config, weights)
        weights.switch_process_group(ProcessGroupType.LM_HEAD)
        self.lm_head = load_column_multi(
            config,
            prefixes=["lm_head"],
            weights=weights,
            head_size=1,
            lm_head=True,
        )
        self.config = config  # for quantize
        self.attn_mask_fake = self.attn_mask.get_attn_mask(1, dtype=self.dtype, device="npu")
        self.place_holder = torch.tensor([1], dtype=self.dtype, device='npu')

        self.transdata_operation = torch.classes.OperationTorch.OperationTorch("TransdataOperation")
        self.transdata_param = json.dumps({})
        self.transdata_operation.set_param(self.transdata_param)

        self.tp = True  # default the model is tensor parallel
        if self.tp:
            self.mask_start_idx = 0
        else:
            self.mask_start_idx = self.tp_rank

        self.max_decode_dp_token_size = self.max_batch_size
        self.num_experts = config.num_experts
        self.num_experts_per_tok = config.num_experts_per_tok
        self.final_hidden_states = []
        self.expert_array = None
        self.expert_group = torch.tensor([1], dtype=torch.int32).npu()
        self.one_hot = torch.tensor([1], dtype=torch.int32).npu()
        self.zero_hot = torch.tensor([0], dtype=torch.int32).npu()
        self.acl_param = None
        self.acl_operation_inputs = None
        self.cos_table = None
        self.sin_table = None
        self.acl_param_encoder = None
        self.acl_param_decoder = None
        self.ascend_weight = None
        self.enable_fused_routing = False if self.soc_info.need_nz else True
        if hasattr(config, "attn_quantize"):
            self.attn_quantize = config.attn_quantize
        elif self.quantize == "w8a8_dynamic":
            self.attn_quantize = "w8a8"
        else:
            self.attn_quantize = self.quantize

        self.device_expert = assign(config.num_experts, self.mapping.moe_ep.group_size)[self.mapping.moe_ep.rank]
        self.start_device_expert_id = torch.tensor(self.device_expert[0], dtype=torch.int64).npu().view(-1)
        self.max_device_expert_id = torch.tensor([len(self.device_expert) - 1], dtype=torch.int64).npu().view(-1)

        logger.info(f"Qwen-moe ExpertParallelDegree is: {self.ep_level}")

        self.enable_intra_layer_addnorm = True

    def init_ascend_operations(self, config: Qwen2MoeConfig):
        self.acl_encoder_operation = torch.classes.ModelTorch.ModelTorch("qwen_MoeDecoderModel")
        self.acl_decoder_operation = torch.classes.ModelTorch.ModelTorch("qwen_MoeDecoderModel")
        logger.info(">>>> qwen_MoeDecoderModel is called.")

    def register_layer_weights(self, weight_wrapper, layer, is_dense_layer=False):
        layer_dict = layer.state_dict()
        # add input layernorm and self_attn weight
        weight_wrapper.register_moe_layer(layer, self.quantize, dense_layer=is_dense_layer,
                                            attn_quantize_type=self.attn_quantize,
                                            qk_norm=self.config.use_qk_norm)

        if self.config.has_shared_expert:
            shared_experts_layer_names = [
                "mlp.shared_expert.gate_up_proj.linear",
                "mlp.shared_expert.down_proj.linear",
            ]
            for layer_name in shared_experts_layer_names:
                weight_wrapper.weights.append(layer_dict[f"{layer_name}.weight"])
            # add shared experts gate weights
            weight_wrapper.weights.append(layer_dict["mlp.shared_expert_gate.weight"])
        else:
            weight_wrapper.weights.extend([self.place_holder] * 3)

    def get_weights(self):
        attn_wrapper = AttnWrapper(
            norm_name='input_layernorm',
            wrapper_name='self_attn',
            pack_name='c_attn',
            sep_names=['q_proj', 'k_proj', 'v_proj'],
            o_name='c_proj'
        )
        moe_mlp_wrapper = MoeMlpWrapper(
            norm_name='post_attention_layernorm',
            router_name='gate',
            wrapper_name='mlp',
            pack_name='gate_up_proj',
            sep_names=['gate_proj', 'up_proj'],
            down_name='down_proj',
            shared_experts=False,
        )
        weight_wrapper = MoeWeightWrapper(
            self.soc_info,
            self.tp_rank,
            attn_wrapper,
            moe_mlp_wrapper,
            self.config.num_experts
        )
        weight_wrapper.register_embedding(self.model.embed_tokens)
        for i in range(self.num_layers):
            layer = self.model.layers[i]
            self.register_layer_weights(weight_wrapper, layer)

        weight_wrapper.register_model_norm(self.model.norm)
        weight_wrapper.register_model_lmhead(self.lm_head)
        return weight_wrapper

    def init_ascend_weight(self):        
        is_w8a8_dynamic = self.quantize == "w8a8_dynamic"
        ascend_weight_wrapper = self.get_weights()
        self.ascend_weight = ascend_weight_wrapper.weights

        pack_quant_types = ascend_weight_wrapper.pack_quant_type
        attn_linear_types = ascend_weight_wrapper.attn_linear_types
        mlp_linear_types = ascend_weight_wrapper.mlp_linear_types
        moe_linear_types = ascend_weight_wrapper.moe_linear_types
        attn_linear_transpose_types = ascend_weight_wrapper.attn_linear_transpose_types
        mlp_linear_transpose_types = ascend_weight_wrapper.mlp_linear_transpose_types
        moe_linear_transpose_types = ascend_weight_wrapper.moe_linear_transpose_types

        acl_param_dict = {
            "isUnpadInputs": True,
            "normEps": self.config.rms_norm_eps,
            "normType": NormType.RMS_NORM,
            "isFA": False,
            "isBF16": self.dtype == torch.bfloat16,
            "isEmbeddingParallel": True,
            "isLmHeadParallel": True,
            "attnLinearQuantType": attn_linear_types,
            "mlpLinearQuantType": mlp_linear_types,
            "moeLinearQuantType": moe_linear_types,
            "attnLinearTransposeType": attn_linear_transpose_types,
            "mlpLinearTransposeType": mlp_linear_transpose_types,
            "moeLinearTransposeType": moe_linear_transpose_types,
            "lmHeadTransposeType": self.lm_head.linear.trans_flag,
            "enableSwiGLU": True,
            "numAttentionHeadsPerRank": self.num_attention_heads,
            "hiddenSizePerAttentionHead": self.head_size,
            "numHiddenLayers": self.config.num_hidden_layers,
            "numKeyValueHeadsPerRank": self.num_key_value_heads,
            "rank": self.tp_rank,
            "worldSize": self.mapping.world_size,
            "backend": self.soc_info.communication_backend,
            "packQuantType": pack_quant_types,
            "expertParallelDegree": self.ep_level,
            "rankTableFile": ENV.rank_table_file,
            "numOfExperts": self.num_experts,
            "numOfSelectedExperts": self.config.num_experts_per_tok,
            "routingMethod": 'softMaxTopK' if self.soc_info.need_nz else 'integratedSoftmaxTopK',
            "enableFusedRouting": self.enable_fused_routing,
            "isDenseLayer": self.config.is_dense_layer,
            "hasSharedExpert": self.config.has_shared_expert,
            "useQKNorm": self.config.use_qk_norm,
            "linearHasBias": [[self.config.attention_bias, False, False, False]] * self.config.num_hidden_layers,
            "processLogits": 'normalization' if self.config.norm_topk_prob else 'none',
            "numOfDeviceExperts": len(self.device_expert),
            "maxDecodeDpTokenSize": self.max_decode_dp_token_size,
            "enableInitQuant": True if (is_w8a8_dynamic and (not self.soc_info.need_nz)) else False,
            "enableIntraLayerAddNorm": self.enable_intra_layer_addnorm,
            "enableAllToAllMC2": self.ep_level == ExpertParallelDegree.DYNAMIC_EP,
            "enableDpOut": ENV.enable_dp_partition_up,
            "enableDispatchCombineV2": True,
        }
        if self.mapping is not None:
            acl_param_dict.update({"mapping": self.mapping.to_dict_v2()})
        self.acl_param_encoder = json.dumps({**acl_param_dict, "isPrefill": True, "enableLcoc": self.lcoc_enable,
                                             "enableGMMSwigluQuant": False})
        self.acl_param_decoder = json.dumps({**acl_param_dict, "isPrefill": False, "enableLcoc": False,
                                             "enableGMMSwigluQuant": True \
                                                if (is_w8a8_dynamic and (not self.soc_info.need_nz)) else False})

        self.acl_encoder_operation.set_param(self.acl_param_encoder)
        self.acl_decoder_operation.set_param(self.acl_param_decoder)

        self.acl_encoder_operation.set_weight(self.ascend_weight)
        self.acl_decoder_operation.set_weight(self.ascend_weight)

    def prepare_inputs_for_ascend(self, input_ids: torch.Tensor,
                                  position_ids: torch.Tensor,
                                  is_prefill: bool,
                                  kv_cache: List[Tuple[torch.Tensor, torch.Tensor]],
                                  block_tables: torch.Tensor,
                                  slots: torch.Tensor,
                                  input_lengths: torch.Tensor,
                                  max_seq_len: int,
                                  lm_head_indices: Optional[torch.Tensor] = None,
                                  **kwargs):

        attn_padding_idx = self.placeholder
        attn_unpadding_idx = self.placeholder
        ffn_padding_idx = self.placeholder
        ffn_unpadding_idx = self.placeholder
        lm_head_skip_padding_token_indices = self.placeholder
        gather_prenorm_idx = self.placeholder
        padding_idx = self.placeholder
        un_padding_idx = self.placeholder
        dynamic_ep_idx = self.placeholder
        moe_idx = self.placeholder
        
        dep_inputs = [attn_padding_idx, attn_unpadding_idx, ffn_padding_idx,
            ffn_unpadding_idx, lm_head_skip_padding_token_indices, gather_prenorm_idx,
            self.start_device_expert_id, self.max_device_expert_id,
            padding_idx.npu(), un_padding_idx, dynamic_ep_idx, moe_idx, self.placeholder]

        if self.mapping.has_dp():
            if ENV.enable_dp_move_up:
                has_tp = self.mapping.has_attn_tp() or self.mapping.lm_head_tp.group_size > 1
                if not self.distributed_enable or (has_tp and self.distributed_enable):
                    dep_inputs = kwargs.get("dep_inputs", None)
                    dep_inputs = dep_inputs[:6] + \
                                    [self.start_device_expert_id, self.max_device_expert_id] + dep_inputs[6:]
                moe_idx = dep_inputs[-2] # note that moe_idx is the second last tensor in dep_inputs
                self.expert_array = torch.ones(moe_idx.shape[0], dtype=torch.float16).npu().view(-1, 1)
            else:
                message = "Please export DP_MOVE_UP_ENABLE=1 when set attn_dp > 1."
                logger.error(message)
                raise RuntimeError(message)
        else:
            if self.ep_level == ExpertParallelDegree.DYNAMIC_EP:
                message = "Currently do not support ep_level=2 when attn_dp=1."
                logger.error(message)
                raise NotImplementedError(message)
            input_length = len(input_ids)
            self.expert_array = torch.tensor(
                            [j for j in range(input_length * self.config.num_experts_per_tok)],
                            dtype=torch.int32
                            ).npu().view(-1)

        self.acl_param = json.dumps({
            "seqLen": input_lengths.tolist()
        })
        # rope
        self.rotary_embedding.update_cos_sin_cache_total(
            self.dtype,
            self.device,
            self.max_position_embeddings
        )
        self.cos_table = self.rotary_embedding.get_cos_cached_total()
        self.sin_table = self.rotary_embedding.get_sin_cached_total()

        if is_prefill:
            if lm_head_indices is None:
                lm_head_indices = torch.tensor(range(input_ids.shape[0]), dtype=torch.int64, device=input_ids.device)

        if is_prefill:
            if self.soc_info.need_nz:
                pad_maxs = math.ceil(self.max_position_embeddings / 16) * 16
                attention_mask = self.attn_mask.get_attn_mask(pad_maxs, kv_cache[0][0].dtype, kv_cache[0][0].device)
                attention_mask = self.transdata_operation.execute([attention_mask])[0]
            else:
                attention_mask = self.attn_mask.get_attn_mask(128, kv_cache[0][0].dtype,
                                                              kv_cache[0][0].device)
        else:
            attention_mask = self.attn_mask_fake

        self.acl_operation_inputs = [
            input_ids,  # IN_TENSOR_INPUTIDS
            position_ids,  # IN_TENSOR_POSITIONIDS
            self.cos_table,  # IN_TENSOR_COSEMBED
            self.sin_table,  # IN_TENSOR_SINEMBED
            attention_mask,  # IN_TENSOR_ATTENTIONMASK
            block_tables.to(torch.int32),  # IN_TENSOR_BLOCK_TABLES
            slots.to(torch.int32),  # IN_TENSOR_SLOTS
            self.place_holder,  # IN_TENSOR_KV_CACHE_IDX
            self.place_holder,  # IN_TENSOR_TOKEN_OFFSET
            self.place_holder,
            input_lengths.to(torch.int32),  # IN_TENSOR_SEQ_LENGTHS
            lm_head_indices if (is_prefill or (self.mapping.has_dp() and not ENV.enable_dp_partition_up)) 
                            else self.lm_head_indices_fake,  # IN_TENSOR_LOGTIS_INDICES 11
            self.expert_array,
            self.expert_group,
            self.one_hot,
            self.zero_hot
        ]
        # inputs for ep
        self.acl_operation_inputs.extend(dep_inputs)
        return self.acl_operation_inputs, self.acl_param
