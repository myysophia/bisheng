# Copyright Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.
from contextlib import contextmanager
import json
from typing import Optional, List, Tuple

import math
import torch
import torch_npu

from .modeling_qwen2 import FlashQwenModel
from .config_qwen2 import Qwen2Config
from ..base.flash_causal_lm import FlashForCausalLM
from ...utils.env import ENV
from ...utils.data.weight_wrapper import WeightWrapper, AttnWrapper, MlpWrapper
from ...utils.layers import load_column_multi, TensorHead, TensorEmbedding
from ...utils.log import logger, print_log
from ...utils.layers.norm.fast_layer_norm import NormType
from ...utils.layers.linear.linear_utils import LinearUtils
from ...utils.quantize.quant_type import QuantType, LinearTypeV2
from ...utils.op_backend import OpBackend


CPP_QWEN_MODEL_CLASS_NAME = "qwen_QwenDecoderModel"
A2_SOCS = (223, 225)
A3_SOCS = (253, 255)


class FlashQwen2ForCausalLM(FlashForCausalLM):
    def __init__(self, config, weights, **kwargs):
        self.acl_decoder_regression_operation = None
        super().__init__(config, weights, **kwargs)
        self.enable_rope_quant_kvcache = self.config.quantization_config.kv_quant_type is not None

        model_prefix = kwargs.get("model_prefix", "model")
        lmhead_prefix = kwargs.get("lmhead_prefix", "lm_head")
        transformer_wte_parallel = kwargs.get("transformer_wte_parallel", True)
        self.skip_word_embedding = kwargs.get("skip_word_embedding", False)
        self.aclnn_matmul_backend = False
        self._update_matmul_params(self.quantize)
        LinearUtils.soc_info = self.soc_info
        self.transformer = FlashQwenModel(
            config, weights, model_prefix=model_prefix, lmhead_prefix=lmhead_prefix,
            attn_decode_backend=self.attn_decode_backend
        )
        # 如果开启layerskipped
        if self.layerskipped_enable:
            self.plugin_params = kwargs.get('plugin_params', None)
            self.attn_skipped_layers = self.plugin_params.get('attn_skipped_layers', [])
            self.mlp_skipped_layers = self.plugin_params.get('mlp_skipped_layers', [])

        if not transformer_wte_parallel:
            self.transformer.wte = TensorEmbedding(
                prefix=f"{model_prefix}.embed_tokens", weights=weights
            )
            for p in self.transformer.wte.parameters():
                p.requires_grad = False

        if self.quantize == "w8a8sc":
            self.lm_head = TensorHead.load_weight(
                config,
                prefix="lm_head",
                weights=weights,
                is_norm=False,
            )
        else:
            if config.tie_word_embeddings:
                self.lm_head = load_column_multi(
                    config,
                    prefixes=[f"{model_prefix}.embed_tokens"],
                    weights=weights,
                    head_size=1,
                    lm_head=True,
                )
            else:
                self.lm_head = load_column_multi(
                    config,
                    prefixes=[f"{lmhead_prefix}"],
                    weights=weights,
                    head_size=1,
                    lm_head=True,
                )
        self.config = config  # for quantize
        self.attn_mask_fake = self.attn_mask.get_attn_mask(1, dtype=self.dtype, device="npu")
        self.place_holder = torch.tensor([1], dtype=self.dtype, device='npu')

        self.transdata_operation = torch.classes.OperationTorch.OperationTorch("TransdataOperation")
        self.transdata_param = json.dumps({})
        self.transdata_operation.set_param(self.transdata_param)
        self.logits_offset_tensor = None
        if self.enable_greedy_search_opt:
            logits_offset = self.config.vocab_size / self.tp_world_size
            indices = torch.arange(self.tp_world_size, device='npu')
            self.logits_offset_tensor = (indices * logits_offset).to(torch.int32)
        self.ascend_kcache_id = None
        self.ascend_vcache_id = None
        self.acl_param = None
        self.ascend_weight = None
        self.decode_weight = None
        self.acl_multi_lora_encoder_operation = None
        self.acl_multi_lora_decoder_operation = None
        self.acl_base_lora_encoder_operation = None
        self.acl_base_lora_decoder_operation = None
        self.long_seq_enable = False
        qwen2_5_has_yarn = hasattr(self.config, 'rope_scaling') and self.config.rope_scaling.type == 'yarn'
        qwen3_has_yarn = hasattr(self.config, 'rope_scaling') and self.config.rope_scaling.rope_type == 'yarn'
        if qwen2_5_has_yarn or qwen3_has_yarn:
            self.long_seq_enable = True
            if self.config.rope_scaling.attention_factor is None:
                self.attention_factor = 1.0
            else:
                self.attention_factor = float(self.config.rope_scaling.attention_factor)
            if self.config.rope_scaling.factor is None:
                raise ValueError('config.rope_scaling.factor must be set in config.json')
            if self.config.rope_scaling.factor <= 1:
                self.mscale = self.attention_factor
            else:
                self.mscale = float((0.1 * math.log(self.config.rope_scaling.factor) + 1.0) * self.attention_factor)
        self.acl_operation_inputs = [None] * self.get_in_tensor_size(encoder=True, long_seq_enable=self.long_seq_enable)
        # 若开启,则冒烟测试卡50ms数据需重新调整(layer多一个输出,内存占用变大)
        self.enable_intra_layer_add_norm = False
        self.enable_inter_layer_add_norm = False
        self.enable_swiglu_quant = False
        self.flash_comm_once_enabled_flag = False

    def update_adapter_manager(self):
        self.adapter_manager.base_model = self
        self.acl_operation_inputs.extend([None] * (self.num_lora_weight_per_layer * self.num_layers + 1))

    def get_in_tensor_size(self, encoder=True, long_seq_enable=False, regression=False):
        base_size = 12
        if long_seq_enable:
            base_size += 3
        if regression:
            return base_size
        if self.compress_head_enable:
            base_size += 2  # batch_wins, input_length_js
        if self.omni_attention_enable:
            base_size += 2 + 5 * self.config.num_hidden_layers
        if not encoder and self.speculate_enable:
            base_size += 1  # 1: q_len
        return base_size

    def init_ascend_operations(self, config: Qwen2Config):
        self.acl_encoder_operation = torch.classes.ModelTorch.ModelTorch(CPP_QWEN_MODEL_CLASS_NAME)
        self.acl_decoder_operation = torch.classes.ModelTorch.ModelTorch(CPP_QWEN_MODEL_CLASS_NAME)
        if self.flash_comm_gate():
            self.acl_encoder_flashcomm_operation = torch.classes.ModelTorch.ModelTorch(CPP_QWEN_MODEL_CLASS_NAME)
            self.acl_decoder_flashcomm_operation = torch.classes.ModelTorch.ModelTorch(CPP_QWEN_MODEL_CLASS_NAME)
        if self.prefix_cache_enable:
            self.acl_decoder_regression_operation = torch.classes.ModelTorch.ModelTorch(CPP_QWEN_MODEL_CLASS_NAME)
        if self.enable_dap:
            self.acl_dap_operation = torch.classes.ModelTorch.ModelTorch(CPP_QWEN_MODEL_CLASS_NAME)
        logger.info(">>>> qwen_QwenDecoderModel is called.")

    def get_weights(self, quantize_type: QuantType = None):
        quantize_type = self.quantize if quantize_type is None else quantize_type
        attn_wrapper = AttnWrapper(
            norm_name='ln_1',
            wrapper_name='attn',
            pack_name='c_attn',
            sep_names=['q_proj', 'k_proj', 'v_proj'],
            o_name='c_proj'
        )
        mlp_wrapper = MlpWrapper(
            norm_name='ln_2',
            wrapper_name='mlp',
            pack_name='w2_w1',
            sep_names=['w2', 'w1'],
            down_name='c_proj'
        )
        kwargs = {
            "enable_rope_quant_kvcache": self.enable_rope_quant_kvcache,
            "enable_swiglu_quant": self.enable_swiglu_quant
        }
        weight_wrapper = WeightWrapper(self.soc_info, self.tp_rank, attn_wrapper, mlp_wrapper, **kwargs)
        weight_wrapper.register_embedding(self.transformer.wte)
        for i in range(self.num_layers):
            layer = self.transformer.h[i]
            weight_wrapper.register_layer(layer, quantize_type)
            if self.config.use_qk_norm:
                weight_wrapper.register_model_norm(layer.attn.q_norm)  # q_norm
                weight_wrapper.register_model_norm(layer.attn.k_norm)  # k_norm
            if self.enable_intra_layer_add_norm or self.enable_inter_layer_add_norm:
                weight_wrapper.register_layer_addrmsnormquant(layer, attn_wrapper, mlp_wrapper, self.quantize)
            if self.soc_info.need_nz and self.adapter_manager is None:
                del layer.attn
                del layer.ln_2
                del layer.mlp
            if self.config.quantization_config.kv_quant_type is not None:
                weight_wrapper.register_layer_kvquant(layer)
            if self.config.quantization_config.fa_quant_type is not None:
                weight_wrapper.register_layer_qkvquant(layer)
        weight_wrapper.register_model_norm(self.transformer.ln_f)
        weight_wrapper.register_model_lmhead(self.lm_head)
        return weight_wrapper

    def init_ascend_weight(self):
        if self.quantize == QuantType.W8A8_PDMIX:
            weight_wrapper = self.get_weights(quantize_type=QuantType.W8A8_DYNAMIC)
            decode_weight_wrapper = self.get_weights(quantize_type=QuantType.W8A8)
            self.decode_weight = decode_weight_wrapper.weights
        else:
            weight_wrapper = self.get_weights()
        self.ascend_weight = weight_wrapper.weights
        linear_types = weight_wrapper.linear_type
        pack_quant_configs = weight_wrapper.pack_quant_type
        linear_descs_configs = weight_wrapper.linear_descs
        linear_transpose_types = weight_wrapper.linear_transpose_types

        if self.quantize == QuantType.W8A8_PDMIX:
            linear_descs_configs = [[linear_desc if linear_desc != LinearTypeV2.W8A8_PDMIX else
                LinearTypeV2.W8A8_DYNAMIC for linear_desc in linear_descs] for linear_descs in linear_descs_configs]
            decode_linear_descs_configs = [[linear_desc if linear_desc != LinearTypeV2.W8A8_DYNAMIC else
                LinearTypeV2.W8A8 for linear_desc in linear_descs] for linear_descs in linear_descs_configs]
        else:
            decode_linear_descs_configs = linear_descs_configs
        if self.config.model_type == "qwen3":
            linear_has_bias = [[self.config.attention_bias, False, False, False]] * self.config.num_hidden_layers
        else:
            linear_has_bias = [[True, False, False, False]] * self.config.num_hidden_layers
        acl_param_dict = {
            "isFA": False,
            "isBF16": self.dtype == torch.bfloat16,
            "skipWordEmbedding": self.skip_word_embedding,
            "isEmbeddingParallel": True,
            "isLmHeadParallel": True,
            "linearTransposeType": linear_transpose_types,
            "lmHeadTransposeType": self.lm_head.linear.trans_flag,
            "enableSwiGLU": False if self.soc_info.need_nz else True,
            "enableSwigluQuant": self.enable_swiglu_quant,
            "enablePreFetchWeight": False,
            "normEps": self.config.rms_norm_eps,
            "normType": NormType.RMS_NORM,
            "numAttentionHeadsPerRank": self.num_attention_heads,
            "hiddenSizePerAttentionHead": self.head_size,
            "numHiddenLayers": self.config.num_hidden_layers,
            "numKeyValueHeadsPerRank": self.num_key_value_heads,
            "rank": self.tp_rank,
            "isUnpadInputs": True,
            "enableFA3": self.config.quantization_config.fa_quant_type is not None,
            "worldSize": self.tp_world_size,
            "backend": self.soc_info.communication_backend,
            "attnBackend": self.attn_decode_backend,
            "linearQuantType": linear_types,
            "packQuantType": pack_quant_configs,
            "quantGroupSize": self.config.quantization_config.group_size,
            "enableKvQuant": self.config.quantization_config.kv_quant_type is not None,
            "enableLora": self.adapter_manager is not None,
            "isLongSeq": self.long_seq_enable,
            "enableAddNorm": False,
            "isYarn": self.long_seq_enable,
            "mscale": self.mscale if self.long_seq_enable else 1.0,
            "rankTableFile": ENV.rank_table_file,
            "useQKNorm": self.config.use_qk_norm,
            "linearHasBias": linear_has_bias,
            "matmulBackend": OpBackend.ACLNN if self.aclnn_matmul_backend else OpBackend.ATB,
            "enableIntraLayerAddNorm": self.enable_intra_layer_add_norm,
            "enableInterLayerAddNorm": self.enable_inter_layer_add_norm,
            "enableGreedySearchOpt": self.enable_greedy_search_opt,
            "enableOmniAttention": self.omni_attention_enable,
            "enableQScale": (self.config.transformers_version == "4.43.1" or
                            self.config.transformers_version == "4.44.0") and \
                            self.config.num_hidden_layers == 28 and \
                            self.soc_info.need_nz,
                            # QwenCode2.5-7B-Instruct/Qwen2.5-7B/1.5B-Instruct模型时为True, 其他模型为False
            "enableModelConfuscation": self.enable_model_obfuscation,
            "modelConfuscationFd": self.obfuscation_fd,
            "mapping": self.mapping.to_dict_v2(),
        }
        encoder_param = {
            **acl_param_dict,
            "isPrefill": True,
            "enableLcoc": self.lcoc_enable,
            "enableSplitFuse": self.split_fuse_enable,
            "enableMC2": ENV.enable_mc2,
            "linearDescs": linear_descs_configs,
            "enableRopeQuantKvcache": self.enable_rope_quant_kvcache and not self.omni_attention_enable,
        }
        decoder_param = {
            **acl_param_dict,
            "isPrefill": False,
            "enableLcoc": False,
            "enableSpeculate": self.speculate_enable,
            "enablePrefixCache": self.prefix_cache_enable,
            "linearDescs": decode_linear_descs_configs,
            "enableRopeQuantKvcache": self.enable_rope_quant_kvcache,
        }
        if self.omni_attention_enable:
            encoder_param.update({"pattern_mask": self.pattern_mask})
            decoder_param.update({"pattern_mask": self.pattern_mask})

        self.acl_encoder_operation.set_param(json.dumps({**encoder_param}))
        self.acl_decoder_operation.set_param(json.dumps({**decoder_param}))

        self.acl_encoder_operation.set_weight(self.ascend_weight)
        if self.quantize == QuantType.W8A8_PDMIX:
            self.acl_decoder_operation.set_weight(self.decode_weight)
        else:
            self.acl_decoder_operation.set_weight(self.ascend_weight)

        if self.adapter_manager is not None:
            self.acl_multi_lora_encoder_operation = torch.classes.ModelTorch.ModelTorch("qwen_QwenDecoderModel")
            self.acl_multi_lora_decoder_operation = torch.classes.ModelTorch.ModelTorch("qwen_QwenDecoderModel")

            encoder_param.update({"loraEnableGMM": True})
            self.acl_multi_lora_encoder_operation.set_param(json.dumps({**encoder_param}))
            decoder_param.update({"loraEnableGMM": True})
            self.acl_multi_lora_decoder_operation.set_param(json.dumps({**decoder_param}))

            self.acl_multi_lora_encoder_operation.set_weight(self.ascend_weight)
            self.acl_multi_lora_decoder_operation.set_weight(self.ascend_weight)

            self.acl_base_lora_encoder_operation = torch.classes.ModelTorch.ModelTorch("qwen_QwenDecoderModel")
            self.acl_base_lora_decoder_operation = torch.classes.ModelTorch.ModelTorch("qwen_QwenDecoderModel")
            disable_support_lora = {"enableLora": False}
            encoder_param.update(disable_support_lora)
            self.acl_base_lora_encoder_operation.set_param(json.dumps({**encoder_param}))
            decoder_param.update(disable_support_lora)
            self.acl_base_lora_decoder_operation.set_param(json.dumps({**decoder_param}))

            self.acl_base_lora_encoder_operation.set_weight(self.ascend_weight)
            self.acl_base_lora_decoder_operation.set_weight(self.ascend_weight)

        if self.enable_dap and self.acl_dap_operation is not None:
            self.acl_dap_operation.set_param(
                json.dumps({"enableDap": True, **encoder_param, "backend": "hccl", "support_lcoc": False}))
            self.acl_dap_operation.set_weight(self.ascend_weight)

        if self.acl_encoder_flashcomm_operation is not None:
            self.acl_encoder_flashcomm_operation.set_param(
                json.dumps({**encoder_param, "enableFlashComm": True, "backend": "hccl"}))
            self.acl_decoder_flashcomm_operation.set_param(
                json.dumps({**decoder_param, "enableFlashComm": True, "backend": "hccl"}))
            self.acl_encoder_flashcomm_operation.set_weight(self.ascend_weight)

            if self.quantize == QuantType.W8A8_PDMIX:
                self.acl_decoder_flashcomm_operation.set_weight(self.decode_weight)
            else:
                self.acl_decoder_flashcomm_operation.set_weight(self.ascend_weight)

        if self.prefix_cache_enable:
            self.init_prefix_cache_regression_weight(acl_param_dict)

        if self.layerskipped_enable:
            # 跳层的自回归图
            self.acl_part_decoder_operation = torch.classes.ModelTorch.ModelTorch("qwen_QwenDecoderModel")
            # 跳层的并行解码图
            self.acl_part_decoder_with_speculate_operation = \
                torch.classes.ModelTorch.ModelTorch("qwen_QwenDecoderModel")
            
            layer_skipped_decoder_param = decoder_param
            layer_skipped_decoder_param["enableSpeculate"] = False
            layer_skipped_decoder_param["attnSkipLayerSet"] = self.attn_skipped_layers
            layer_skipped_decoder_param["mlpSkipLayerSet"] = self.mlp_skipped_layers
            self.acl_part_decoder_operation.set_param(json.dumps({**layer_skipped_decoder_param}))
            self.acl_part_decoder_operation.set_weight(self.ascend_weight)
            self.layer_skipped_decoder_param = layer_skipped_decoder_param
            layer_skipped_decoder_with_speculate_param = layer_skipped_decoder_param
            layer_skipped_decoder_with_speculate_param["enableSpeculate"] = True
            self.acl_part_decoder_with_speculate_operation.set_param(
                json.dumps({**layer_skipped_decoder_with_speculate_param}))
            self.acl_part_decoder_with_speculate_operation.set_weight(self.ascend_weight)

    def init_prefix_cache_regression_weight(self, coder_param):
        # prefix cache特性多加一张图用于自回归decode
        decoder_regression_param = {
            **coder_param, "isPrefill": False, "enableLcoc": False,
            "enableSpeculate": False
        }
        self.acl_decoder_regression_operation.set_param(json.dumps({**decoder_regression_param}))
        self.acl_decoder_regression_operation.set_weight(self.ascend_weight)

    @contextmanager
    def self_skip_layer(self, speculate_enable=False, *args, **kwargs):
        self.part_decoder = True # 控制跳层
        self.speculate_enable = speculate_enable
        try:
            yield None
        finally:
            self.speculate_enable = True # 控制并行解码
            self.part_decoder = False

    def flash_comm_gate(self):
        # Current support: [soc version] 225 and 223 [model] Qwen3-32B-PDMIX
        # weight_list format: {device_type: {quantize: {num_hidden_layers}}}
        weight_list = {
            225: {QuantType.W8A8_PDMIX: {64}},
            223: {QuantType.W8A8_PDMIX: {64}},
        }
        if self.tp_world_size == 1:
            return False
        if not self.soc_info.is_support_hccs():
            return False
        if self.soc_info.soc_version in weight_list:
            if self.quantize in weight_list[self.soc_info.soc_version]:
                if self.config.num_hidden_layers in weight_list[self.soc_info.soc_version][self.quantize]:
                    return True
        return False

    def pass_flash_comm_threshold(self, input_ids_len):
        # default_value of flash_comm_threshold
        default_value = 1024 * 32
        # Set flash_comm_threshold for different devices with different world_size scenario
        threshold_dict = {
            225: {2: 2000, 4: 1000, 8: 500},
            223: {2: 2000, 4: 1000, 8: 500},
            202: {2: 8000, 4: 4000, 8: 2000}
        }
        if self.soc_info.soc_version in threshold_dict:
            if self.tp_world_size in threshold_dict[self.soc_info.soc_version]:
                flash_comm_threshold = threshold_dict[self.soc_info.soc_version][self.tp_world_size]
            else:
                flash_comm_threshold = default_value
            if input_ids_len >= flash_comm_threshold:
                return True
        return False


    def prepare_inputs_for_ascend(self, input_ids: torch.Tensor,
                                  position_ids: torch.Tensor,
                                  is_prefill: bool,
                                  kv_cache: List[Tuple[torch.Tensor, torch.Tensor]],
                                  block_tables: torch.Tensor,
                                  slots: torch.Tensor,
                                  input_lengths: torch.Tensor,
                                  max_seq_len: int,
                                  lm_head_indices: Optional[torch.Tensor] = None,
                                  **kwargs):
        if self.pass_flash_comm_threshold(input_ids.shape[0]) and self.acl_encoder_flashcomm_operation is not None:
            self.enable_flash_comm = True
        else:
            self.enable_flash_comm = False
        # Flashcomm not support for DAP & Lora
        if self.adapter_manager or self.enable_dap:
            self.enable_flash_comm = False
        if self.enable_flash_comm:
            self.flash_comm_once_enabled_flag = True
        if self.adapter_manager is not None:
            # 更新adapter
            adapter_ids = kwargs.get("adapter_ids")
            effective_adapter_ids = self.process_adapter_ids(adapter_ids)
            adapter_weights = self.prepare_adapter_weights(effective_adapter_ids)
            in_tensor_size = self.get_in_tensor_size(encoder=is_prefill)
            self.update_adapter_weights(adapter_weights, self.acl_operation_inputs, in_tensor_size)
        seqlen = "seqLen"
        self.acl_param = json.dumps({
            seqlen: input_lengths.tolist()
        })
        cos_table, sin_table = None, None
        if self.long_seq_enable:
            self.rotary_embedding.yarn_scaling_rotary_embedding(self.config, self.device, max_seq_len)
        else:
            self.rotary_embedding.update_cos_sin_cache_total(
                self.dtype,
                self.device,
                self.max_position_embeddings
            )
            cos_table = self.rotary_embedding.get_cos_cached_total()
            sin_table = self.rotary_embedding.get_sin_cached_total()

        q_lens = kwargs.get('q_lens', [])

        inv_freq = self.rotary_embedding.ntk_inv_freqs
        position_ids_expanded = self.rotary_embedding.position_ids_expanded
        pos_lens = self.rotary_embedding.pos_lens

        use_regression = False
        if is_prefill:
            attention_mask = self.attn_mask.get_attn_mask(max_seq_len if self.split_fuse_enable else self.max_base_len,
                                                          self.dtype, self.device)
            # BF16 PA算子需要使用-10000.0表示mask掉的部分
            if self.split_fuse_enable and self.dtype == torch.bfloat16:
                attention_mask = attention_mask * -10000.0
            if self.soc_info.need_nz:
                attention_mask = self.transdata_operation.execute([attention_mask])[0]
            if self.split_fuse_enable:
                self.acl_param = json.dumps({
                    seqlen: input_lengths.tolist(),
                    "qLen": q_lens
                })
                q_lens = torch.tensor(q_lens).to(self.device).to(torch.int32)
        else:
            if self.prefix_cache_enable and q_lens == []:  # 开启prefix cache时q_lens为空时使用自回归
                use_regression = True
            if self.skip_word_embedding:
                input_ids = self.transformer.wte(input_ids)
            attention_mask = self.attn_mask_fake

            if self.speculate_enable and not use_regression:
                spec_mask = kwargs.get('spec_mask', None)
                self.acl_param = json.dumps({
                    seqlen: input_lengths.tolist(),
                    "qLen": q_lens
                })
                q_lens = torch.tensor(q_lens).to(self.device).to(torch.int32)
                req_mask = spec_mask
                if self.soc_info.need_nz:
                    req_mask = self.transdata_operation.execute([req_mask])[0]
                attention_mask = req_mask

        if lm_head_indices is None:
            lm_head_indices = torch.tensor(range(input_ids.shape[0]), dtype=torch.int64, device=input_ids.device)
        if use_regression or not (is_prefill or self.prefix_cache_enable):
            lm_head_indices = self.lm_head_indices_fake

        acl_operation_inputs_ = [
            input_ids,  # IN_TENSOR_INPUTIDS
            position_ids if not self.long_seq_enable else position_ids_expanded, # IN_TENSOR_POSITIONIDS
            self.place_holder if self.long_seq_enable else cos_table,  # IN_TENSOR_COSEMBED
            self.place_holder if self.long_seq_enable else sin_table,  # IN_TENSOR_SINEMBED
            attention_mask,  # IN_TENSOR_ATTENTIONMASK
            self.placeholder if self.omni_attention_enable else block_tables.to(torch.int32),  # IN_TENSOR_BLOCK_TABLES
            self.placeholder if self.omni_attention_enable else slots.to(torch.int32),  # IN_TENSOR_SLOTS
            self.place_holder,  # IN_TENSOR_KV_CACHE_IDX
            self.place_holder,  # IN_TENSOR_TOKEN_OFFSET
            self.place_holder,
            input_lengths.to(torch.int32),  # IN_TENSOR_SEQ_LENGTHS
            lm_head_indices,  # IN_TENSOR_LOGTIS_INDICES
        ]  # 0-11
        
        if self.enable_greedy_search_opt:
            acl_operation_inputs_.append(self.logits_offset_tensor)

        if self.omni_attention_enable:
            wins = kwargs.get("wins")
            in_attn_seqlens = kwargs.get("in_attn_seqlens")
            pffset_index = kwargs.get("pffset_index")
            ra_offset = kwargs.get("ra_offset")
            in_reshape_seqlen = kwargs.get('in_reshape_seqlen')
            acl_operation_inputs_.append(wins)
            acl_operation_inputs_.append(in_reshape_seqlen)
            block_size = kv_cache[0][0].shape[1]
            block_nums_list = [i[0].shape[0] * block_size for i in kv_cache]

            for layer_idx in range(self.config.num_hidden_layers):
                razor_offset_end_idx = int(block_nums_list[layer_idx] / ra_offset.shape[-1])
                acl_operation_inputs_.append(block_tables[layer_idx])
                acl_operation_inputs_.append(slots[layer_idx])
                acl_operation_inputs_.append(in_attn_seqlens[layer_idx])
                acl_operation_inputs_.append(pffset_index[layer_idx])
                acl_operation_inputs_.append(ra_offset[layer_idx][:razor_offset_end_idx, :])
            input_lengths_list = input_lengths.tolist()
            self.acl_param = json.dumps({
                    "seqLen": input_lengths_list,
                    "qLen": [],
                    "blockNumsList": block_nums_list
            })
        if self.long_seq_enable:  # 12-14 for long_seq
            acl_operation_inputs_.append(inv_freq)
            acl_operation_inputs_.append(pos_lens)
            acl_operation_inputs_.append(position_ids)

        if self.speculate_enable and not is_prefill and not use_regression:
            acl_operation_inputs_.append(q_lens) # 15
        if is_prefill:
            if self.split_fuse_enable:
                acl_operation_inputs_.append(q_lens)
            if self.adapter_manager is not None and effective_adapter_ids != ["base"]:
                acl_operation_input_lora = self.calculate_adapter_group_size(
                    effective_adapter_ids, input_lengths.to(torch.int32), is_prefill=True)
                acl_operation_inputs_.append(acl_operation_input_lora) # 12
        else:
            if self.adapter_manager is not None and effective_adapter_ids != ["base"]:
                acl_operation_input_lora = self.calculate_adapter_group_size(
                    effective_adapter_ids, torch.ones_like(input_ids, device=self.device, dtype=torch.int64),
                    is_prefill=False)
                acl_operation_inputs_.append(acl_operation_input_lora) # 12

        # Generate flashcomm intensors
        if self.enable_flash_comm:
            split_size = math.floor(input_ids.shape[0] / self.tp_world_size)
            remain_size = input_ids.shape[0] % self.tp_world_size
            # send_bs: input_ids list for each cards
            send_bs = torch.full((self.tp_world_size,), split_size, dtype=torch.int64)
            # send_counts: AllGatherV's and ReduceScatter's data, receive and send data for each cards
            send_counts = torch.full((self.tp_world_size,), split_size * self.hidden_size, dtype=torch.int64)
            for i in range(self.tp_world_size):
                if i < remain_size:
                    send_bs[i] += 1
                    send_counts[i] += 1 * self.hidden_size
            cum_counts = torch.cumsum(send_counts, dim=0)
            # sdispls: ReduceScatterV data, the offset list of the send input_ids for each card
            sdispls = torch.cat((torch.zeros(1, dtype=torch.int64), cum_counts[:-1]))
            cum_bs = torch.cumsum(send_bs, dim=0)
            # rdispls: AllGatherV data, the offset list of the receive data for each card
            rdispls = torch.cat((torch.zeros(1, dtype=torch.int64), cum_bs[:-1]))
            send_count = torch.tensor([send_bs[self.tp_rank]], dtype=torch.int64)
            recv_count = torch.tensor([send_counts[self.tp_rank]], dtype=torch.int64)
            fake_rs_shape = torch.zeros([send_bs[self.tp_rank]], dtype=torch.float16)
            fake_ag_shape = torch.zeros([input_ids.shape[0]], dtype=torch.float16)
            acl_param_dict = json.loads(self.acl_param)
            acl_param_dict.update({
                "sendCounts": send_counts.tolist(),
                "sdispls": sdispls.tolist(),
                "sendCount": send_count.tolist(),
                "recvCounts": send_bs.tolist(),
                "rdispls": rdispls.tolist(),
                "recvCount": recv_count.tolist(),
            })
            self.acl_param = json.dumps(acl_param_dict)
            acl_operation_inputs_.append(send_counts.npu())
            acl_operation_inputs_.append(sdispls.npu())
            acl_operation_inputs_.append(send_count.npu())
            acl_operation_inputs_.append(send_bs.npu())
            acl_operation_inputs_.append(rdispls.npu())
            acl_operation_inputs_.append(recv_count.npu())
            acl_operation_inputs_.append(fake_rs_shape.npu())
            acl_operation_inputs_.append(fake_ag_shape.npu())
        if self.flash_comm_once_enabled_flag:
            self.acl_operation_inputs = acl_operation_inputs_
            return self.acl_operation_inputs, self.acl_param
        if (self.speculate_enable or self.split_fuse_enable or self.layerskipped_enable):
            self.acl_operation_inputs = acl_operation_inputs_
        else:
            self.acl_operation_inputs[:len(acl_operation_inputs_)] = acl_operation_inputs_        
        return self.acl_operation_inputs, self.acl_param

    def execute_ascend_operator(self,
                                acl_inputs,
                                acl_param,
                                is_prefill):
        has_multiple_adapter_ids, only_base_adapter = False, False
        if self.adapter_manager is not None:
            if self.adapter_manager.previous_adapter_ids.adapter_ids == ["base"]:
                only_base_adapter = True
            elif acl_inputs[12].shape[0] != 1:
                has_multiple_adapter_ids = True
        if is_prefill:
            # lora-多adapter
            if has_multiple_adapter_ids:
                model_operation = self.acl_multi_lora_encoder_operation
            # lora-base 走基础组图
            elif only_base_adapter:
                model_operation = self.acl_base_lora_encoder_operation
                acl_inputs = acl_inputs[:12]
            # flashcomm graph
            elif self.enable_flash_comm:
                model_operation = self.acl_encoder_flashcomm_operation
            # lora-单个adapter and 非lora其他情况
            else:
                model_operation = self.acl_encoder_operation
        else:
            if self.prefix_cache_enable and len(acl_inputs) == \
                    self.get_in_tensor_size(encoder=False, long_seq_enable=self.long_seq_enable, regression=True):
                model_operation = self.acl_decoder_regression_operation  # prefix cache自回归decode
            elif only_base_adapter:
                model_operation = self.acl_base_lora_decoder_operation
                acl_inputs = acl_inputs[:12]
            elif has_multiple_adapter_ids:
                model_operation = self.acl_multi_lora_decoder_operation
            elif self.layerskipped_enable and self.part_decoder and not self.speculate_enable:
                model_operation = self.acl_part_decoder_operation
            elif self.layerskipped_enable and self.part_decoder and self.speculate_enable:
                model_operation = self.acl_part_decoder_with_speculate_operation
            elif self.enable_flash_comm:
                model_operation = self.acl_decoder_flashcomm_operation
            else:
                model_operation = self.acl_decoder_operation

        acl_model_out = model_operation.execute(acl_inputs, acl_param)
        try:
            acl_hidden_state = acl_model_out[0]
        except IndexError as e:
            raise RuntimeError("运行时报错，请开启日志进一步定位问题") from e
        return acl_hidden_state

    def init_kvcache(self, kv_cache):
        kcache_id_diff = self.ascend_kcache_id != id(kv_cache[0][0])
        vcache_id_diff = self.ascend_vcache_id != id(kv_cache[0][1])
        kcache_shape_diff = self.ascend_kcache_shape != kv_cache[0][0].shape
        vcache_shape_diff = self.ascend_vcache_shape != kv_cache[0][1].shape
        kcache_diff = not self.ascend_kcache_id or kcache_id_diff or kcache_shape_diff
        vcache_diff = not self.ascend_vcache_id or vcache_id_diff or vcache_shape_diff
        if kcache_diff or vcache_diff:
            k_caches, v_caches = map(lambda x: list(x), zip(*kv_cache))
            print_log(self.tp_rank, logger.info, f"<<<<<<< ori {k_caches[0].shape=}")
            if self.soc_info.need_nz:
                k_caches = [torch_npu.npu_format_cast_(k_cache, 29) for k_cache in k_caches]
                v_caches = [torch_npu.npu_format_cast_(v_cache, 29) for v_cache in v_caches]
                logger.info(f"<<<<<<<after transdata {k_caches[0].shape=}")
            self.acl_encoder_operation.set_kv_cache(k_caches, v_caches)
            self.acl_decoder_operation.set_kv_cache(k_caches, v_caches)
            if self.acl_encoder_flashcomm_operation is not None:
                self.acl_encoder_flashcomm_operation.set_kv_cache(k_caches, v_caches)
                self.acl_decoder_flashcomm_operation.set_kv_cache(k_caches, v_caches)
            if self.prefix_cache_enable:
                self.acl_decoder_regression_operation.set_kv_cache(k_caches, v_caches)
            if self.layerskipped_enable:
                self.acl_part_decoder_operation.set_kv_cache(k_caches, v_caches)
                self.acl_part_decoder_with_speculate_operation.set_kv_cache(k_caches, v_caches)
            if self.acl_multi_lora_encoder_operation is not None:
                self.acl_multi_lora_encoder_operation.set_kv_cache(k_caches, v_caches)
            if self.acl_multi_lora_decoder_operation is not None:
                self.acl_multi_lora_decoder_operation.set_kv_cache(k_caches, v_caches)
            if self.acl_base_lora_encoder_operation is not None:
                self.acl_base_lora_encoder_operation.set_kv_cache(k_caches, v_caches)
            if self.acl_base_lora_decoder_operation is not None:
                self.acl_base_lora_decoder_operation.set_kv_cache(k_caches, v_caches)
            if self.acl_dap_operation is not None:
                self.acl_dap_operation.set_kv_cache(k_caches, v_caches)
            self.ascend_kcache_id = id(kv_cache[0][0])
            self.ascend_vcache_id = id(kv_cache[0][1])
            self.ascend_kcache_shape = kv_cache[0][0].shape
            self.ascend_vcache_shape = kv_cache[0][1].shape
            print_log(self.tp_rank, logger.info,
                      f">>>>>>id of kcache is {self.ascend_kcache_id} id of vcache is {self.ascend_vcache_id}")

    def _update_matmul_params(self, quantize: QuantType):
        is_float = quantize is None or quantize == QuantType.FLOAT
        is_aclnn_qmm = quantize in (QuantType.W8A8, QuantType.W8A8_DYNAMIC, QuantType.W8A8_PDMIX)
        if self.soc_info.soc_version in (A2_SOCS + A3_SOCS) and (is_float or is_aclnn_qmm):
            self.soc_info.matmul_nd_nz = True

            # in (A2 + fp16 + float) or aclnn_qmm cases, using aclnn backend
            if (self.soc_info.soc_version in A2_SOCS and is_float and self.dtype == torch.float16):
                self.aclnn_matmul_backend = True
            if is_aclnn_qmm:
                self.aclnn_matmul_backend = True