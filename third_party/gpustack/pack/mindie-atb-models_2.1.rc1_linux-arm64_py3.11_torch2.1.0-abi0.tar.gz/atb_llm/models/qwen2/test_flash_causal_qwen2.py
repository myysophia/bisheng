# Copyright Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.

import unittest
from unittest.mock import MagicMock, patch

import torch

from atb_llm.utils import OpBackend
from atb_llm.utils.dist import FakeGroup
from atb_llm.utils.mapping import Mapping
from atb_llm.models.qwen2.config_qwen2 import Qwen2Config
from atb_llm.models.qwen2.flash_causal_qwen2 import FlashQwen2ForCausalLM
from tests.pythontest.atb_llm.models.base.mock_class import MockTorchClasses


class TestFlashCausalQwen(unittest.TestCase):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.mock_torch_classes = None

    def setUp(self):
        self.mock_torch_classes = MockTorchClasses()
        torch.classes = self.mock_torch_classes
        self.config = Qwen2Config(
            hidden_size=1024,
            max_position_embeddings=1024,
            num_attention_heads=28,
            num_key_value_heads=4,
            num_hidden_layers=28,
            pe_type="ROPE",
            rope_scaling={"rope_theta": 1.0, "factor": 2.0},
            rms_norm_eps=1e-6,
        )
        self.config.routed_scaling_factor = 2
        self.config.n_group = 1
        self.config.topk_group = 1
        self.config.topk_method = None
        self.config.parallel_embedding = True
        self.weights = MagicMock()
        self.weights.device = torch.device("npu")
        self.weights.dtype = torch.bfloat16
        self.weights.quantize = None
        self.weights.get_tensor.return_value = torch.empty(100, 100, dtype=torch.bfloat16)
        self.weights.get_multi_weights_col.return_value = torch.empty(100, 100, dtype=torch.bfloat16)
        self.weights.get_replicated_weights.return_value = torch.empty(100, 100, dtype=torch.bfloat16)
        self.weights.get_multi_weights_row.return_value = torch.empty(100, 100, dtype=torch.bfloat16)
        self.weights.get_whole_tensor.return_value = torch.empty(100, 100, dtype=torch.bfloat16)
        self.weights.get_shape.return_value = [100, 100]
        self.weights.switch_process_group.return_value = None

        self.weights.process_group = FakeGroup(0, 2)
        self.weights.mapping = Mapping(world_size=2, rank=0)
        self.weights.mapping.attn_tp.rank = 1

    @patch("atb_llm.models.base.flash_causal_lm.load_atb_speed")
    @patch('atb_llm.models.qwen2.flash_causal_qwen2.FlashQwenModel', return_value=MagicMock())
    @patch('atb_llm.models.qwen2.flash_causal_qwen2.load_column_multi')
    def test_init_tie_word_embeddings_false(self, mock_load_column_multi, mock_model, mock_init_so):
        _ = FlashQwen2ForCausalLM(self.config, self.weights)
        mock_model.assert_called_once_with(self.config, self.weights, model_prefix="model", lmhead_prefix="lm_head",
                                           attn_decode_backend=OpBackend.ATB)

    @patch("atb_llm.models.base.flash_causal_lm.load_atb_speed")
    @patch('atb_llm.models.qwen2.flash_causal_qwen2.FlashQwenModel', return_value=MagicMock())
    @patch('atb_llm.models.qwen2.flash_causal_qwen2.load_column_multi')
    def test_model_prepare_inputs_decode_flash_comm(self, mock_load_column_multi, mock_model, mock_init_so):
        instance0 = FlashQwen2ForCausalLM(self.config, self.weights)
        batch_size = 500
        golden_input_ids = torch.tensor([12] * batch_size).npu()
        golden_block_tables = torch.tensor([1, 2]).npu()
        golden_slots = torch.tensor([0, 1, 2]).npu()
        golden_position_ids = torch.tensor([0, 1, 2], dtype=torch.int32).npu()
        golden_kv_cache = [(torch.tensor([23561, 235, 18]).npu(), torch.tensor([23561, 235, 18]).npu()) for \
                           i in range(2)]
        golden_input_lengths = torch.tensor([2, 1]).npu()
        golden_max_seq_len = 10
        acl_operation_inputs, acl_param = instance0.prepare_inputs_for_ascend(
            golden_input_ids, golden_position_ids, False, golden_kv_cache, golden_block_tables,
            golden_slots, golden_input_lengths, golden_max_seq_len, lm_head_indices=None
        )
        self.assertEqual(len(acl_operation_inputs), 20)
        self.assertTrue(instance0.enable_flash_comm, True)
