# Copyright Huawei Technologies Co., Ltd. 2023-2024. All rights reserved.
import json

import torch

from atb_llm import nn
from atb_llm.models.base.base_lm import BaseLM
from atb_llm.models.base.config import BaseConfig
from atb_llm.utils.weights import Weights
from atb_llm.utils.data.weight_wrapper import WeightWrapper, AttnWrapper, MlpWrapper
from atb_llm.models.base.engine.engine_manager import engine_manager
from atb_llm.utils.op_backend import OpBackend
from atb_llm.utils.layers.norm.fast_layer_norm import NormType
from atb_llm.utils.quantize.quant_type import QuantType, LinearTypeV2

LINEAR_DESCS_KEY = "linearDescs"    # key of linearDescs in static engine parameters


class BaseLMCpp(BaseLM, nn.Module):
    """
    Base class for language models that leverages an inference engine implemented in C++.

    Args:
        config (BaseConfig): model configuration.
        weights (Weights): Weights object to load model weights.
        **kwargs: Additional keyword arguments.
    """
    def __init__(self, config: BaseConfig, weights: Weights, **kwargs):
        super().__init__(config, weights, **kwargs)
        nn.Module.__init__(self)

        # model weights
        self.attn_wrapper = AttnWrapper(
            norm_name='input_layernorm',
            wrapper_name='self_attn',
            pack_name='query_key_value',
            sep_names=['q_proj', 'k_proj', 'v_proj'],
            o_name='o_proj'
        )

        self.mlp_wrapper = MlpWrapper(
            norm_name='post_attention_layernorm',
            wrapper_name='mlp',
            pack_name='gate_up_proj',
            sep_names=['gate_proj', 'up_proj'],
            down_name='down_proj'
        )

        self.attn_decode_backend = OpBackend.ACLNN if self.config.quantization_config.kv_quant_type is not None \
                                   else OpBackend.ATB

        # engine static parameters
        self.engine_static_param = None

        # model weights
        self.device_weights = []
        self.optional_device_weights = None

        # engine input
        self.engine_inputs = []
        # 若开启,则冒烟测试卡50ms数据需重新调整(layer多一个输出,内存占用变大)
        self.enable_intra_layer_add_norm = False
        self.enable_inter_layer_add_norm = False
        self.enable_rope_quant_kvcache = False
        self.enable_swiglu_quant = False

    @property
    def model_torch_class_name(self) -> str:
        """
        Returns the name of the PyTorch class used by the model.
        This method is intended to be overridden by subclasses.
        """
        pass

    def update_engine_static_param(self):
        """
        Sets the inference engine's static parameters based on the model configuration and parameters.
        These parameters will be pass to the C++ class identified by `model_torch_class_name`.
        Returns:
            dict: A dictionary of parameters.
        """
        return {
            "normEps": self.config.rms_norm_eps,
            "normType": NormType.RMS_NORM,
            "positionEmbeddingType": self.config_metadata.position_embedding_type,
            "numAttentionHeadsPerRank": self.config_metadata.num_attention_heads,
            "hiddenSizePerAttentionHead": self.config_metadata.head_dim,
            "numHiddenLayers": self.config_metadata.num_hidden_layers,
            "numKeyValueHeadsPerRank": self.config_metadata.num_key_value_heads,
            "isBF16": self.torch_dtype == torch.bfloat16,
            "isLmHeadParallel": True,
            "rank": self.mapping.rank,
            "worldSize": self.mapping.world_size,
            "backend": self.soc_info.communication_backend,
            "attnBackend": self.attn_decode_backend,
            "enableLcoc": self.infer_param.enable_lcoc,
            "enableSwiGLU": False if self.soc_info.need_nz else True,
            "enableSwigluQuant": self.enable_swiglu_quant,
            "enableKvQuant": self.config.quantization_config.kv_quant_type is not None,
            "enableFA3": self.config.quantization_config.fa_quant_type is not None,
            "enableReduceQuant": self.config.quantization_config.reduce_quant_type is not None,
            "quantGroupSize": self.config.quantization_config.group_size,
        }

    def get_device_weights(self, **kwargs) -> WeightWrapper:
        """
        Retrieves the weights for the device.

        Args:
            **kwargs: Additional keyword arguments.

        Returns:
            WeightWrapper: The weight wrapper object contains weight metadata.
        """
        model = self.getattr_by_alias('model')
        quantize_type = kwargs.get('quantize_type', self.config.quantize)
        weight_kwargs = {
            "enable_rope_quant_kvcache": self.enable_rope_quant_kvcache,
            "enable_swiglu_quant": self.enable_swiglu_quant
        }
        weight_wrapper = WeightWrapper(self.soc_info, self.mapping.rank, self.attn_wrapper, self.mlp_wrapper, 
                                       **weight_kwargs)
        weight_wrapper.register_embedding(model.getattr_by_alias('embed_tokens'))
        for i in range(self.config_metadata.num_hidden_layers):
            layer = model.getattr_by_alias('layers')[i]
            weight_wrapper.register_layer(layer, quantize_type)
            if hasattr(self.config, "use_qk_norm") and self.config.use_qk_norm:
                weight_wrapper.register_model_norm(layer.attn.q_norm)  # q_norm
                weight_wrapper.register_model_norm(layer.attn.k_norm)  # k_norm
            if self.enable_intra_layer_add_norm or self.enable_inter_layer_add_norm:
                weight_wrapper.register_layer_addrmsnormquant(layer, self.attn_wrapper, self.mlp_wrapper,
                                                              self.config.quantize)
            if self.config.quantization_config.kv_quant_type is not None:
                weight_wrapper.register_layer_kvquant(layer)
            if self.config.quantization_config.fa_quant_type is not None:
                weight_wrapper.register_layer_qkvquant(layer)
            if self.config.quantization_config.reduce_quant_type is not None:
                weight_wrapper.register_layer_reducequant(layer)
        weight_wrapper.register_model_norm(model.getattr_by_alias('norm'))
        weight_wrapper.register_model_lmhead(self.getattr_by_alias('lm_head'))
        return weight_wrapper

    def build_engines(self, **kwargs) -> None:
        """
        Builds inference engines for the model based on model parameters.

        Args:
            **kwargs: Additional keyword arguments.
        """
        self.engine_static_param = self.update_engine_static_param()
        if self.config.quantize == QuantType.W8A8_PDMIX:
            weight_wrapper = self.get_device_weights(quantize_type=QuantType.W8A8_DYNAMIC)
            decode_weight_wrapper = self.get_device_weights(quantize_type=QuantType.W8A8)
            self.optional_device_weights = decode_weight_wrapper.weights
        else:
            weight_wrapper = self.get_device_weights()
        self.device_weights = weight_wrapper.weights
        linear_descs = weight_wrapper.linear_descs
        linear_transpose_types = weight_wrapper.linear_transpose_types
        is_anti_outlier = weight_wrapper.is_anti_outlier

        engine_weight_param = {
            "linearTransposeType": linear_transpose_types,
            "isAntiOutlier": is_anti_outlier,
            "lmHeadTransposeType": self.lm_head.linear.trans_flag,
        }

        if self.config.quantize == QuantType.W8A8_PDMIX:
            prefill_linear_descs = [[linear_desc if linear_desc != LinearTypeV2.W8A8_PDMIX else
                LinearTypeV2.W8A8_DYNAMIC for linear_desc in layer_linear_descs]
                for layer_linear_descs in linear_descs]
            decode_linear_descs = [[linear_desc if linear_desc != LinearTypeV2.W8A8_PDMIX else LinearTypeV2.W8A8
                for linear_desc in layer_linear_descs] for layer_linear_descs in linear_descs]
            for engine_class in engine_manager.get_engine_classes(self):
                if engine_class.is_prefill:
                    engine_wrapper = engine_class(self, engine_weight_param={**engine_weight_param, 
                                                                             LINEAR_DESCS_KEY: prefill_linear_descs})
                    engine_wrapper.set_weights(self.device_weights)
                else:
                    engine_wrapper = engine_class(self, engine_weight_param={**engine_weight_param,
                                                                             LINEAR_DESCS_KEY: decode_linear_descs})
                    engine_wrapper.set_weights(self.optional_device_weights)
                engine_manager.register_engine(engine_wrapper)
        else:
            for engine_class in engine_manager.get_engine_classes(self):
                engine_wrapper = engine_class(self, engine_weight_param={**engine_weight_param,
                                                                         LINEAR_DESCS_KEY: linear_descs})
                engine_wrapper.set_weights(self.device_weights)
                engine_manager.register_engine(engine_wrapper)

    def execute_engine(self, **kwargs) -> torch.Tensor:
        """
        Executes the engine to generate the model's output.

        Args:
            **kwargs: Additional keyword arguments.

        Returns:
            torch.Tensor: Logits.

        Raises:
            RuntimeError: If engine execution fails.
        """
        engine = engine_manager.choose_engine(self, **kwargs)
        try:
            engine_outputs = engine.execute(self.engine_inputs, json.dumps(self.engine_runtime_param))
            hidden_state = engine_outputs[0]
        except IndexError as e:
            raise RuntimeError("Engine execution error. "
                               "Enable log: export ASDOPS_LOG_LEVEL=ERROR, "
                               "export ASDOPS_LOG_TO_STDOUT=1 to find the first error. "
                               "For more details, see the MindIE official document.") from e
        return hidden_state

    def execute_dap_engine(self, **kwargs) -> torch.Tensor:
        engine = engine_manager.choose_engine(self, **kwargs)
        try:
            engine_outputs = engine.execute(self.engine_inputs, json.dumps(self.engine_runtime_param))
        except IndexError as e:
            raise RuntimeError("Engine execution error. "
                               "Enable log: export ASDOPS_LOG_LEVEL=ERROR, "
                               "export ASDOPS_LOG_TO_STDOUT=1 to find the first error. "
                               "For more details, see the MindIE official document.") from e
        if len(engine_outputs) != 2:
            raise RuntimeError("Number of output tensors is not equal to the expected value.")
        return engine_outputs
