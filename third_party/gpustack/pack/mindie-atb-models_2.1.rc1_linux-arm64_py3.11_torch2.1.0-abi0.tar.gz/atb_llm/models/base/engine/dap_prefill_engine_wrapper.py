# Copyright Huawei Technologies Co., Ltd. 2024-2025. All rights reserved.
from atb_llm.models.base.base_lm import BaseLM
from atb_llm.models.base.engine.engine_wrapper import EngineWrapper


class DapPrefillEngineWrapper(EngineWrapper):
    is_prefill: bool = True

    def create_engine(self, context: BaseLM, **kwargs):
        if context.infer_param.enable_python_engine:
            raise NotImplementedError
        else:
            engine_weight_param = kwargs.get('engine_weight_param', {})
            engine = super().create_engine_cpp(
                context.model_torch_class_name,
                {**context.engine_static_param, **engine_weight_param, "isPrefill": self.is_prefill,
                 "skipWordEmbedding": context.infer_param.skip_word_embedding, "enableDap": True,
                 "backend": "hccl", "enableLcoc": False}
            )
        return engine

    def activate(self, context: BaseLM, **kwargs) -> bool:
        is_prefill = kwargs.get("is_prefill", False)
        enable_dap = kwargs.get("enable_dap", False)
        return is_prefill and enable_dap
