# Copyright Huawei Technologies Co., Ltd. 2024-2025. All rights reserved.
from atb_llm.models.base.base_lm import BaseLM
from atb_llm.models.base.engine.engine_wrapper import EngineWrapper


class MultiLoraDecodeEngineWrapper(EngineWrapper):
    is_prefill: bool = False

    def create_engine(self, context: BaseLM, **kwargs):
        """Create an engine for multiple lora adapters, utilized in the decode phase.
        For C++ engine, apart from default parameters passed through `context.engine_static_param`,
            the following key value pair will be updated: {"isPrefill": False, "enableLcoc": False,
            "enableLora": True, "loraEnableGMM": True}.

        Args:
            context (BaseLM): All the necessary parameters needed to initialize the engine.

        Raises:
            NotImplementedError: if `context.infer_param.enable_python_engine` is true,
            an `NotImplementedError` will be raised. Python engine is not supported.

        Returns:
            An inference engine instance.
        """
        if context.infer_param.enable_python_engine:
            raise NotImplementedError
        else:
            engine_weight_param = kwargs.get('engine_weight_param', {})
            engine = super().create_engine_cpp(
                context.model_torch_class_name,
                {**context.engine_static_param, **engine_weight_param, "isPrefill": self.is_prefill,
                 "enableLcoc": False, "enableLora": True, "loraEnableGMM": True}
            )
        return engine

    def activate(self, context: BaseLM, **kwargs) -> bool:
        """A function that determines whether to use the current `engine` for inference.
        This object is activated when `is_prefill` from `kwargs` is false and multiple adapters are enabled.

        Args:
            context (BaseLM): All the necessary parameters needed to initialize the engine.
            kwargs: All the inference inputs needed to choose the engine.

        Returns:
            bool: A flag indicating whether the current `engine` is activated.
        """
        is_prefill = kwargs.get("is_prefill", False)
        return not is_prefill and context.lora_decorator.use_multi_adapters()
