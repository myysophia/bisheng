# Part of this file was copied from the vLLM team, vLLM project,
# adapted from vllm/vllm/entrypoints/openai/tool_parsers/hermes_tool_parser.py
#
# SPDX-License-Identifier: Apache-2.0
#
# Copyright (c) Huawei Technologies Co., Ltd. 2024-2025. All rights reserved.

import json
import random
import string
import re
from typing import Optional, Literal, Dict, Pattern

from pydantic import BaseModel

from atb_llm.utils.json_completor import FillMode, complete_json_for_toolcall
from atb_llm.utils.log import logger

JSON_END_WITH_QUOTATION = '"}'
JSON_END_CURLY_BRACKET = '}'
SPECIAL_DELTA_PREFIXES = ['{"', "{'"]

CONTENT = "content"
TOOL_CALLS = "tool_calls"
NAME = "name"
ARGUMENTS = "arguments"

TOOL_CALL_ID_LEN = 8


class ToolsCallProcessor:
    """Base class for tools call processor."""

    def __init__(self, model_version: str):
        self.model_version = model_version

    def decode(self, content) -> Dict:
        """Parse model output to extract tools call output."""
        return {CONTENT: content}


class DeltaFunctionCall(BaseModel):
    name: Optional[str] = None
    arguments: Optional[str] = None


class DeltaToolCall(BaseModel):
    id: Optional[str] = None
    type: Optional[Literal["function"]] = None
    index: int
    function: Optional[DeltaFunctionCall] = None


class ToolsCallProcessorWithXml(ToolsCallProcessor):

    def __init__(self, tokenizer):
        super().__init__(model_version="")
        self.tokenizer = tokenizer
        self.current_tool_name_sent: bool = False
        self.current_tool_arguments_sent: bool = False
        self.current_tool_id: int = -1

    @property
    def stream_tool_call_portion_regex(self) -> Pattern:
        return None

    @property
    def stream_tool_call_name_regex(self) -> Pattern:
        return None

    @property
    def tool_call_start_token(self) -> str:
        raise NotImplementedError("Subclasses must implement the 'tool_call_start_token' property.")

    @property
    def tool_call_end_token(self) -> str:
        raise NotImplementedError("Subclasses must implement the 'tool_call_end_token' property.")

    @property
    def tool_call_start_token_id(self) -> int:
        raise NotImplementedError("Subclasses must implement the 'tool_call_start_token_id' property.")

    @property
    def tool_call_end_token_id(self) -> int:
        raise NotImplementedError("Subclasses must implement the 'tool_call_end_token_id' property.")

    @property
    def tool_call_regex(self) -> Pattern:
        raise NotImplementedError("Subclasses must implement the 'tool_call_regex' property.")

    @staticmethod
    def random_tool_call_id() -> str:
        return "call_" + ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(TOOL_CALL_ID_LEN))

    @staticmethod
    def get_tool_call_json(matches):
        try:
            tool_calls = [json.loads(match) for match in matches]
            for item in tool_calls:
                _ = item[NAME]
                _ = item[ARGUMENTS]
        except Exception:
            tool_calls = []
        return tool_calls

    def get_current_tool_call_with_regex(self, tool_call_portion, fill_mode):
        current_tool_call = {}
        current_tool_call_matches = (
            self.stream_tool_call_portion_regex.match(
                tool_call_portion))
        if current_tool_call_matches:
            _, tool_name, tool_args = (
                current_tool_call_matches.groups())
            current_tool_call[NAME] = tool_name
            current_tool_call[ARGUMENTS] = complete_json_for_toolcall(tool_args, fill_mode)
        else:
            current_tool_call_name_matches = (
                self.stream_tool_call_name_regex.match(
                    tool_call_portion))
            if current_tool_call_name_matches:
                _, tool_name = (
                    current_tool_call_name_matches.groups())
                current_tool_call[NAME] = tool_name
                current_tool_call[ARGUMENTS] = ""
        return current_tool_call

    def decode(self, content) -> Dict:
        """
        example content:
        <tool_call>
            {"name": "get_rectangle_property", "arguments": {"perimeter": 14, "area": 15, "property": "length"}}
        </tool_call>
        """
        lines = content.strip()
        matches = self.tool_call_regex.findall(lines)
        tool_calls = self.get_tool_call_json(matches) if matches else None
        if not tool_calls:
            return {CONTENT: lines}
        call_res = []
        for item in tool_calls:
            tool_call = {
                NAME: item[NAME],
                ARGUMENTS: json.dumps(item[ARGUMENTS], ensure_ascii=False) \
                    if isinstance(item[ARGUMENTS], dict) else item[ARGUMENTS]
            }
            res = {
                "type": "function",
                "id": self.random_tool_call_id(),
                "function": tool_call
            }
            call_res.append(res)
        return {CONTENT: content.split(self.tool_call_start_token)[0], TOOL_CALLS: call_res}

    def decode_stream(self, all_token_ids: list[int], prev_decode_index: int, curr_decode_index: int,
                      skip_special_tokens: bool, delta_text: str) -> Dict:
        init_return_none = {}
        try:
            full_text = self.tokenizer.decode(all_token_ids, skip_special_tokens=skip_special_tokens)
            history_token_ids = all_token_ids[:curr_decode_index]
            if self.tool_call_start_token_id not in all_token_ids:  # before tool_calls common content
                return {CONTENT: delta_text}
            prev_tool_start_count, prev_tool_end_count, cur_tool_start_count, cur_tool_end_count = (
                self._count_tool_tokens(history_token_ids, all_token_ids))
            fill_mode = FillMode.Full if self.current_tool_name_sent else FillMode.BraceOnly
            delta = {}
            # case1：common content
            if (cur_tool_start_count == cur_tool_end_count and prev_tool_end_count == cur_tool_end_count
                    and self.tool_call_end_token not in delta_text):
                return {CONTENT: delta_text}
            # case2：start new tool_call
            if cur_tool_start_count > cur_tool_end_count and cur_tool_start_count > prev_tool_start_count:
                self.current_tool_id += 1
                self.current_tool_name_sent = False
                self.current_tool_arguments_sent = False
                text_portion, tool_call_portion = delta_text.split(self.tool_call_start_token)
                return {CONTENT: text_portion} if text_portion else init_return_none
            # case3：update tool_call
            elif cur_tool_start_count > cur_tool_end_count and cur_tool_start_count == prev_tool_start_count:
                tool_call_portion = full_text.split(self.tool_call_start_token)[-1]
            # case4：over tool_call
            elif cur_tool_start_count == cur_tool_end_count and cur_tool_end_count >= prev_tool_end_count:
                # The arguments have been sent. The prevention part follows the end tag.
                if not self.current_tool_arguments_sent:
                    return init_return_none
                if JSON_END_WITH_QUOTATION not in delta_text:
                    return init_return_none
                diff = delta_text[: delta_text.rindex(JSON_END_WITH_QUOTATION)] + JSON_END_WITH_QUOTATION
                return {TOOL_CALLS: [
                    DeltaToolCall(index=self.current_tool_id,
                                  function=DeltaFunctionCall(arguments=diff)).model_dump(exclude_none=True)
                ]}
            else:
                delta_text = delta_text.replace(self.tool_call_start_token, "").replace(self.tool_call_end_token, "")
                return {CONTENT: delta_text}
            try:
                # 解析tool_call_portion
                if self.stream_tool_call_name_regex is None:
                    current_tool_call = complete_json_for_toolcall(tool_call_portion or "{}",
                                                fill_mode) if tool_call_portion else None
                else:
                    current_tool_call = self.get_current_tool_call_with_regex(tool_call_portion,
                                                            fill_mode) if tool_call_portion else None
            except Exception:
                # Invalid JSON fragment newline characters.
                return init_return_none

            # case1：send function name
            if not self.current_tool_name_sent:
                if current_tool_call is None or not current_tool_call.get(NAME):
                    return init_return_none
                self.current_tool_name_sent = True
                return {TOOL_CALLS: [
                    DeltaToolCall(index=self.current_tool_id, type="function", id=self.random_tool_call_id(),
                                  function=DeltaFunctionCall(name=current_tool_call.get(NAME))).model_dump(
                        exclude_none=True)
                ]}

            # case2：send param
            cur_arguments = current_tool_call.get(ARGUMENTS)
            if cur_arguments and not self.current_tool_arguments_sent:
                # case2-1:send arguments contains structure.example {"arguments":"{\"order_id\": \""}
                cur_arguments_json = json.dumps(cur_arguments, ensure_ascii=False)
                # get the location where previous args differ from current
                last_brace_index = cur_arguments_json.rfind("}")
                if last_brace_index == -1:
                    return init_return_none

                if any(prefix in delta_text for prefix in SPECIAL_DELTA_PREFIXES):
                    if delta_text not in tool_call_portion:
                        return init_return_none
                    pattern = r'["\']arguments["\']\s*:\s*(\{.*\}|\[.*\]|[^,;}\n]*)'
                    matched = re.search(pattern, tool_call_portion, re.DOTALL)
                    if matched:
                        argument_portion = matched.group(1).strip()
                    else:
                        argument_portion = None
                else:
                    argument_portion = cur_arguments_json[:last_brace_index + 1]
                start_pos = argument_portion.rfind(delta_text)
                if start_pos == -1:
                    return init_return_none    
                arguments_delta = argument_portion[:start_pos + len(delta_text)]
                delta = {TOOL_CALLS: [
                    DeltaToolCall(index=self.current_tool_id,
                                  function=DeltaFunctionCall(arguments=arguments_delta).model_dump(exclude_none=True))
                    .model_dump(exclude_none=True)
                ]}
                self.current_tool_arguments_sent = True
            elif cur_arguments and self.current_tool_arguments_sent:
                # case2-2:arguments delta content
                if isinstance(delta_text, str) and len(delta_text.rstrip()) >= 1 and delta_text.rstrip()[
                    -1] == JSON_END_CURLY_BRACKET:
                    # delete the end brace of the whole tool call json
                    if _count_closing_braces_at_end(tool_call_portion) > \
                        _count_closing_braces_at_end(json.dumps(cur_arguments, ensure_ascii=False)):
                        delta_text = delta_text.rstrip()[:-1]
                delta = {TOOL_CALLS: [
                    DeltaToolCall(index=self.current_tool_id,
                                  function=DeltaFunctionCall(arguments=delta_text)).model_dump(exclude_none=True)
                ]}
            return delta
        except Exception:
            logger.error("An exception occurred when parsing the function call. The large model response is invalid.")
            return init_return_none

    def _count_tool_tokens(self, history_token_ids, all_token_ids):
        prev_tool_start_count = history_token_ids.count(self.tool_call_start_token_id)
        prev_tool_end_count = history_token_ids.count(self.tool_call_end_token_id)
        cur_tool_start_count = all_token_ids.count(self.tool_call_start_token_id)
        cur_tool_end_count = all_token_ids.count(self.tool_call_end_token_id)
        return prev_tool_start_count, prev_tool_end_count, cur_tool_start_count, cur_tool_end_count


def _count_closing_braces_at_end(text: str):
    text = text.rstrip()
    count = 0
    for char in reversed(text):
        if char == "}":
            count += 1
        else:
            break
    return count