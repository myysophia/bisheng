# Copyright Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
from dataclasses import dataclass

from .config_qwen3_moe import Qwen3MoeConfig
from ..qwen3.input_builder_qwen3 import Qwen3InputBuilder
from ..qwen3.tool_call_process_qwen3 import ToolsCallProcessorQwen3
from ..base.reasoning_parser import CommonReasoningParser
from ..qwen2_moe.router_qwen2_moe import Qwen2moeRouter


@dataclass
class Qwen3moeRouter(Qwen2moeRouter):

    def __post_init__(self):
        # qwen3系列 继承qwen2系列
        super().__post_init__()
        self.model_type = "qwen2_moe"
        self.model_type_cap = self.model_type.capitalize().replace('_', '')
        self.transformers_version = self.config_dict["transformers_version"]

    @property
    def config(self):
        self.config_dict.update({"transformers_version": self.transformers_version})
        config = Qwen3MoeConfig.from_dict(self.config_dict)
        super().check_config(config)
        return config

    def get_reasoning_parser(self):
        """initialize reasoning parser"""
        return CommonReasoningParser(self.config)

    def get_toolscallprocessor(self):
        return ToolsCallProcessorQwen3(self.tokenizer)

    def get_input_builder(self):
        return Qwen3InputBuilder(self.tokenizer)
