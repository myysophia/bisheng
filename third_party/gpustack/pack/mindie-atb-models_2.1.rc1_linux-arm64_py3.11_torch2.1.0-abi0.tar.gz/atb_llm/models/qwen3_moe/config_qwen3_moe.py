# Copyright Huawei Technologies Co., Ltd. 2024. All rights reserved.

from dataclasses import dataclass
from ..qwen2_moe.configuration_qwen2_moe import Qwen2MoeConfig


@dataclass
class Qwen3MoeConfig(Qwen2MoeConfig):
    norm_topk_prob: bool = True
    has_shared_expert: bool = False
    use_qk_norm: bool = True
    is_reasoning_model: bool = True
    start_reasoning_token_id = 151667
    end_reasoning_token_id = 151668

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.reasoning_config.start_reasoning_token_id = self.start_reasoning_token_id
        self.reasoning_config.end_reasoning_token_id = self.end_reasoning_token_id