import { getCursorPosition } from "../util/selection";

// 模块作用域变量
let placeholderTimer: any = null;
let placeholderElement: any = null;

export const placeholder = (inputing: boolean, vditor: any) => {
    console.log('inputing :>> ', inputing);
    const config = vditor.options.hint.placeholder
    if (!config) return
    const { delay = 2000, text = '请输入@' } = config
    // 清除之前的定时器
    if (placeholderTimer) {
        clearTimeout(placeholderTimer);
        placeholderTimer = null;
        if (placeholderElement) {
            placeholderElement.style.display = 'none';
        }
    }

    // 用户停止输入，设置2秒后显示提示
    placeholderTimer = setTimeout(() => {
        const editorElement = vditor[vditor.currentMode].element;
        const { top: cursorTop, left: cursorLeft } = getCursorPosition(editorElement);


        const selection = window.getSelection();
        if (!selection || selection.rangeCount === 0) return;

        // 获取当前光标位置
        const range = selection.getRangeAt(0);
        if (!range.collapsed || range.commonAncestorContainer.textContent !== '') {
            // 非空行退出
            return;
        }
        // 获取编辑器在页面中的位置
        const editorRect = editorElement.getBoundingClientRect();

        // 计算绝对位置（考虑编辑器位置和页面滚动）
        const absoluteLeft = editorRect.left + cursorLeft + window.scrollX;
        const absoluteTop = editorRect.top + cursorTop + window.scrollY;

        // 检查光标后是否有文本内容
        let hasTextAfter = false;
        // 方法1: 检查当前文本节点是否有后续文本
        if (range.startContainer.nodeType === Node.TEXT_NODE) {
            const text = range.startContainer.textContent || '';
            if (text.length > range.startOffset) {
                hasTextAfter = true;
            }
        }

        // 方法2: 检查后续兄弟节点
        // if (!hasTextAfter) {
        //     let nextNode = range.startContainer.nextSibling;
        //     while (nextNode) {
        //         if (nextNode.textContent && nextNode.textContent.trim().length > 0) {
        //             hasTextAfter = true;
        //             break;
        //         }
        //         nextNode = nextNode.nextSibling;
        //     }
        // }

        // 方法3: 检查父节点的后续内容
        // if (!hasTextAfter) {
        //     let parent = range.startContainer.parentNode;
        //     while (parent) {
        //         if (parent.textContent && parent.textContent.length > range.startOffset) {
        //             hasTextAfter = true;
        //             break;
        //         }
        //         parent = parent.parentNode;
        //     }
        // }

        // 如果光标后有文本内容，不显示提示
        if (hasTextAfter) {
            if (placeholderElement) {
                placeholderElement.style.display = 'none';
            }
            return;
        }

        // 创建或显示占位提示
        if (!placeholderElement) {
            placeholderElement = document.createElement('div');
            placeholderElement.id = 'vditor-placeholder-at'
            placeholderElement.className = 'placeholder-tooltip event-none';
            placeholderElement.textContent = text;
            document.body.appendChild(placeholderElement);
        }

        // 设置位置并显示

        placeholderElement.style.left = `${absoluteLeft + 10}px`; // 添加10px水平偏移避免遮挡光标
        placeholderElement.style.top = `${absoluteTop}px`;
        placeholderElement.style.display = 'block';

    }, delay); // 2秒后显示
};