import { processCodeRender } from "../util/processCode";
import { afterRenderEvent } from "./afterRenderEvent";

export const renderDomByMd = (vditor: IVditor, md: string, options = {
    enableAddUndoStack: true,
    enableHint: false,
    enableInput: true,
}) => {
    const editorElement = vditor.wysiwyg.element;
    const html = vditor.lute.Md2VditorDOM(md);
    // 自定义更新渲染数据
    editorElement.innerHTML = html.replace(/\{\{(.*?)\}\}/g, '<span class="linsi-span" contenteditable="false">$1</span>')

    editorElement.querySelectorAll(".vditor-wysiwyg__preview[data-render='2']").forEach((item: HTMLElement) => {
        processCodeRender(item, vditor);
        item.previousElementSibling.setAttribute("style", "display:none");
    });

    afterRenderEvent(vditor, options);
};
