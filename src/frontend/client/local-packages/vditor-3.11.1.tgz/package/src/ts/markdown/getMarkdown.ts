import { code160to32 } from "../util/code160to32";

export const getMarkdown = (vditor: IVditor) => {
    if (vditor.currentMode === "sv") {
        return code160to32(`${vditor.sv.element.textContent}\n`.replace(/\n\n$/, "\n"));
    } else if (vditor.currentMode === "wysiwyg") {
        const html = vditor.wysiwyg.element.innerHTML.replace(/<span class="linsi-span" contenteditable="false">(.*?)<\/span>/g, '{{@$1@}}')
            .replace(/<span class="linsi-error" contenteditable="false"><\/span>/g, '{{#$1#}}');
        return vditor.lute.VditorDOM2Md(html);
    } else if (vditor.currentMode === "ir") {
        return vditor.lute.VditorIRDOM2Md(vditor.ir.element.innerHTML);
    }
    return "";
};
