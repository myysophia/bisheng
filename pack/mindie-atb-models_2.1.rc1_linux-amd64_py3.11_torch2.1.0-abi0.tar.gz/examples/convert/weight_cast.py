# Copyright Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
import os
import json
from pathlib import Path
import re
import torch
import torch_npu
import acl
from safetensors import safe_open
from safetensors.torch import save_file

from atb_llm.utils.argument_utils import ArgumentParser, StringArgumentValidator
from atb_llm.utils.file_utils import MAX_PATH_LENGTH
from atb_llm.utils.log import logger


def parse_arguments():
    """
    解析命令行参数。

    参数:
        --model_path (str): 模型和分词器的路径。
        --save_directory (str): 保存转换后的权重的新路径。
        --index_file (str): 模型权重的索引文件名。
    """
    parser = ArgumentParser()
    parser.add_argument('--model_path', type=str, help="model and tokenizer path",
                        validator=StringArgumentValidator(min_length=1, max_length=MAX_PATH_LENGTH))
    parser.add_argument('--save_directory', type=str, help="save the converted weights to the new path",
                        validator=StringArgumentValidator(min_length=1, max_length=MAX_PATH_LENGTH))
    parser.add_argument('--index_file', type=str, help="the index file name of model weights",
                        validator=StringArgumentValidator(min_length=1, max_length=MAX_PATH_LENGTH))
    return parser.parse_args()


def check_path_valid(dir_path):
    if not Path(dir_path).is_absolute():
        raise ValueError(f"The path of {dir_path} must be absolute.")
    if not Path(dir_path).is_dir():
        raise ValueError(f"The path of {dir_path} is not a directory.")
    if not Path(dir_path).exists():
        raise ValueError(f"The path of {dir_path} is not exists.")


class WeightCast:
    def __init__(self, args):
        self.model_path = args.model_path
        self.save_directory = args.save_directory
        self.index_file = args.index_file

    def cast(self, **kwargs):
        check_path_valid(self.model_path)
        check_path_valid(self.save_directory)
        index_path = os.path.join(self.model_path, self.index_file)
        if not os.path.exists(index_path):
            raise FileExistsError(f"{index_path} does not exists.")
        with open(index_path, 'r', encoding='utf-8') as file:
            index_json = json.load(file)

        weight_map = index_json['weight_map']
        safetensor_names = list(set(weight_map.values()))
        filters = {
            "experts.gate_proj": r"model.layers.\d+.mlp.experts.\d+.gate_proj",  # gate_proj
            "experts.up_proj": r"model.layers.\d+.mlp.experts.\d+.up_proj",  # up_proj
            "experts.down_proj": r"model.layers.\d+.mlp.experts.\d+.down_proj",  # down_proj
        }

        for sf_name in safetensor_names:
            logger.info(f"cur sf file: {sf_name}")
            sf_path = os.path.join(self.model_path, sf_name)
            if not os.path.exists(sf_path):
                continue
            with safe_open(sf_path, framework="torch") as f:
                # List all keys in the file
                keys = f.keys()
                # Load tensors
                tensors = {key: f.get_tensor(key) for key in keys}
                for key, tensor in tensors.items():
                    if re.match(filters["experts.gate_proj"], key) or re.match(filters["experts.up_proj"],
                                                                               key) or re.match(
                            filters["experts.down_proj"], key):
                        if "weight_" in key:  # 跳过 scale 和 offset
                            continue

                        tensor_npu = tensor.npu()
                        if "down_" in key:  # 跳过 down
                            continue
                        else:
                            tensor_npu = tensor_npu.permute(1, 0).contiguous()
                        torch.npu.config.allow_internal_format = True
                        tensor_npu = torch_npu.npu_format_cast_(tensor_npu, 29)
                        if tensor_npu.untyped_storage().size() != tensor_npu.numel() * tensor_npu.element_size():
                            raise RuntimeError("Cast failed because nz format need more memory space.")
                        tensor_cpu = torch.empty_like(tensor_npu, device='cpu')
                        torch.npu.synchronize()
                        acl.rt.memcpy(tensor_cpu.untyped_storage().data_ptr(), tensor_cpu.untyped_storage().nbytes(),
                                      tensor_npu.untyped_storage().data_ptr(), tensor_npu.untyped_storage().nbytes(), 2)
                        tensors[key] = tensor_cpu

            new_sf_path = os.path.join(self.save_directory, sf_name)
            save_file(tensors, new_sf_path)
            logger.info(f"save to sf file: {new_sf_path} success.")
        return 0


if __name__ == '__main__':
    args = parse_arguments()
    WeightCast(args).cast()
